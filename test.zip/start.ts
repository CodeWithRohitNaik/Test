require("module-alias/register");
import * as appInsights from "applicationinsights";
import * as dotenv from "dotenv";
dotenv.config();
import { init, start } from "./server";

appInsights
    .setup(process.env.APPLICATION_INSIGHTS_KEY || "NO_INSTRUMENT")
    .setAutoCollectRequests(true)
    .setAutoCollectPerformance(true, true)
    .setAutoCollectExceptions(true)
    .setAutoCollectDependencies(true)
    .setAutoCollectConsole(true, false)
    .setAutoCollectPreAggregatedMetrics(true)
    .setSendLiveMetrics(false)
    .setInternalLogging(false, true)
    .enableWebInstrumentation(false)
    .start();

const options = {
    port: process.env.PORT || 8080,
};
init(options).then(() => start());

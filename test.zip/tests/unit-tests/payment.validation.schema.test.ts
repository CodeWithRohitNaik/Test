import { describe, expect, it } from "@jest/globals";
import { getPaymentSchema, postPaymentSchema } from "../../src/validations/payment.validation.schema";

describe("Payment Validation Schema", () => {
    describe("postPaymentSchema", () => {
        it("should validate a correct payment object", () => {
            const validPayment = {
                id: "123",
                type: "payment",
                localTimeIso: "2023-01-01T00:00:00.000Z",
                version: "1.0",
                data: {
                    tripId: "trip123",
                    tripNumber: "tripNumber123",
                    bookingId: "bookingId123",
                    merchantId: "merchant123",
                    isPartial: false,
                    dispatchHandlesPartial: false,
                    vehicle: {
                        registrationPlate: "ABC123",
                        watModified: true,
                        vehicleStatus: "Operational",
                        vehicleId: "vehicle123",
                    },
                    driver: {
                        tssAuthorisationNumber: "auth123",
                        abn: "abn123",
                        dispatchDriverId: "driver123",
                        dispatchShiftId: "shift123",
                    },
                    meter: {
                        meterManufacturer: "manufacturer123",
                        meterStatus: "status123",
                        meterModel: "model123",
                        meterSoftwareVersion: "version123",
                        meterId: "meter123",
                        meterType: "SoftMeter",
                    },
                    dispatch: {
                        dispatchManufacturer: "manufacturer123",
                        dispatchModel: "model123",
                        dispatchSoftwareVersion: "version123",
                        dispatchDeviceId: "device123",
                        dispatchSystemId: "system123",
                    },
                    fare: {
                        isMetered: true,
                        isBooked: true,
                        isPrepayment: true,
                        metersTravelled: 1000,
                        startTimeIso: "2023-01-01T00:00:00.000Z",
                        endTimeIso: "2023-01-01T01:00:00.000Z",
                        requestedAmountCents: 1000,
                        flagFallAmountCents: 500,
                        meteredAmountCents: 500,
                        meterExtrasCents: 100,
                        richTripDataUrl: "http://example.com",
                        pickUpGps: {
                            lat: 10.0,
                            lon: 20.0,
                            shortDescription: "pickup",
                            timestampIso: "2023-01-01T00:00:00.000Z",
                        },
                        dropOffGps: {
                            lat: 30.0,
                            lon: 40.0,
                            shortDescription: "dropoff",
                            timestampIso: "2023-01-01T01:00:00.000Z",
                        },
                        waypoints: [
                            {
                                lat: 15.0,
                                lon: 25.0,
                                shortDescription: "waypoint",
                                timestampIso: "2023-01-01T00:30:00.000Z",
                            },
                        ],
                        tariffs: [
                            {
                                id: "tariff123",
                                name: "tariffName",
                                description: "tariffDescription",
                                flagfallAmountCents: 200,
                            },
                        ],
                    },
                    extendedFare: {
                        tolls: [
                            {
                                name: "tollName",
                                amountCents: 300,
                                automaticallyApplied: true,
                                amountPreset: true,
                                entryGantryWaypoint: {
                                    lat: 10.0,
                                    lon: 20.0,
                                },
                                exitGantryWaypoint: {
                                    lat: 30.0,
                                    lon: 40.0,
                                },
                            },
                        ],
                        levies: [
                            {
                                name: "levyName",
                                amountCents: 100,
                                automaticallyApplied: true,
                                amountPreset: true,
                            },
                        ],
                        extras: [
                            {
                                name: "extraName",
                                amountCents: 50,
                                automaticallyApplied: true,
                                amountPreset: true,
                            },
                        ],
                        other: [
                            {
                                name: "otherName",
                                amountCents: 75,
                                automaticallyApplied: true,
                                amountPreset: true,
                            },
                        ],
                    },
                },
            };

            const { error } = postPaymentSchema.validate(validPayment);
            expect(error).toBeUndefined();
        });

        it("should invalidate an incorrect payment object", () => {
            const invalidPayment = {
                id: "123",
                type: "payment",
                localTimeIso: "invalid-date",
                version: "1.0",
                data: {
                    tripId: "trip123",
                    merchantId: "merchant123",
                    vehicle: {
                        registrationPlate: "ABC123",
                        watModified: true,
                        vehicleStatus: "Operational",
                        vehicleId: "vehicle123",
                    },
                    driver: {
                        tssAuthorisationNumber: "auth123",
                        abn: "abn123",
                    },
                    meter: {
                        meterManufacturer: "manufacturer123",
                        meterId: "meter123",
                        meterType: "SoftMeter",
                    },
                    dispatch: {
                        dispatchManufacturer: "manufacturer123",
                        dispatchModel: "model123",
                        dispatchSoftwareVersion: "version123",
                        dispatchDeviceId: "device123",
                    },
                    fare: {
                        isMetered: true,
                        isBooked: true,
                        isPrepayment: true,
                        startTimeIso: "2023-01-01T00:00:00.000Z",
                        requestedAmountCents: 1000,
                        pickUpGps: {
                            lat: 10.0,
                            lon: 20.0,
                        },
                        dropOffGps: {
                            lat: 30.0,
                            lon: 40.0,
                        },
                    },
                },
            };

            const { error } = postPaymentSchema.validate(invalidPayment);
            expect(error).toBeDefined();
        });

        it("should validate a payment object with optional fields", () => {
            const paymentWithOptionalFields = {
                id: "123",
                type: "payment",
                localTimeIso: "2023-01-01T00:00:00.000Z",
                version: "1.0",
                data: {
                    tripId: "trip123",
                    merchantId: "merchant123",
                    vehicle: {
                        registrationPlate: "ABC123",
                        watModified: true,
                        vehicleStatus: "Operational",
                        vehicleId: "vehicle123",
                    },
                    driver: {
                        tssAuthorisationNumber: "auth123",
                        abn: "abn123",
                    },
                    meter: {
                        meterManufacturer: "manufacturer123",
                        meterId: "meter123",
                        meterType: "SoftMeter",
                    },
                    dispatch: {
                        dispatchManufacturer: "manufacturer123",
                        dispatchModel: "model123",
                        dispatchSoftwareVersion: "version123",
                        dispatchDeviceId: "device123",
                    },
                    fare: {
                        isMetered: false,
                        isBooked: true,
                        isPrepayment: true,
                        startTimeIso: "2023-01-01T00:00:00.000Z",
                        requestedAmountCents: 1000,
                        pickUpGps: {
                            lat: 10.0,
                            lon: 20.0,
                        },
                        dropOffGps: {
                            lat: 30.0,
                            lon: 40.0,
                        },
                    },
                    extendedFare: {
                        tolls: [
                            {
                                name: "tollName",
                                amountCents: 300,
                                automaticallyApplied: true,
                                amountPreset: true,
                            },
                        ],
                    },
                },
            };

            const { error } = postPaymentSchema.validate(paymentWithOptionalFields);
            expect(error).toBeUndefined();
        });

        it("should invalidate a payment object with incorrect optional fields", () => {
            const paymentWithIncorrectOptionalFields = {
                id: "123",
                type: "payment",
                localTimeIso: "2023-01-01T00:00:00.000Z",
                version: "1.0",
                data: {
                    tripId: "trip123",
                    merchantId: "merchant123",
                    vehicle: {
                        registrationPlate: "ABC123",
                        watModified: true,
                        vehicleStatus: "Operational",
                        vehicleId: "vehicle123",
                    },
                    driver: {
                        tssAuthorisationNumber: "auth123",
                        abn: "abn123",
                    },
                    meter: {
                        meterManufacturer: "manufacturer123",
                        meterId: "meter123",
                        meterType: "SoftMeter",
                    },
                    dispatch: {
                        dispatchManufacturer: "manufacturer123",
                        dispatchModel: "model123",
                        dispatchSoftwareVersion: "version123",
                        dispatchDeviceId: "device123",
                    },
                    fare: {
                        isMetered: true,
                        isBooked: true,
                        isPrepayment: true,
                        startTimeIso: "2023-01-01T00:00:00.000Z",
                        requestedAmountCents: 1000,
                        pickUpGps: {
                            lat: 10.0,
                            lon: 20.0,
                        },
                        dropOffGps: {
                            lat: 30.0,
                            lon: 40.0,
                        },
                    },
                    extendedFare: {
                        tolls: [
                            {
                                name: "tollName",
                                amountCents: "invalid-amount",
                                automaticallyApplied: true,
                                amountPreset: true,
                            },
                        ],
                    },
                },
            };

            const { error } = postPaymentSchema.validate(paymentWithIncorrectOptionalFields);
            expect(error).toBeDefined();
        });
    });

    describe("getPaymentSchema", () => {
        it("should validate a correct get payment object", () => {
            const validGetPayment = {
                dispatchId: "dispatch123",
                paymentRequestId: "550e8400-e29b-41d4-a716-446655440000",
            };

            const { error } = getPaymentSchema.validate(validGetPayment);
            expect(error).toBeUndefined();
        });

        it("should invalidate an incorrect get payment object", () => {
            const invalidGetPayment = {
                dispatchId: "dispatch123",
                paymentRequestId: "invalid-uuid",
            };

            const { error } = getPaymentSchema.validate(invalidGetPayment);
            expect(error).toBeDefined();
        });
    });
});

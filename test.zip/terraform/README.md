# prepare to run terraform scripts

need to create a resource group because do not have permission for creating resource group in PROD
need to create a keyvault and set "registry-password-secret" first
need to add the app-registraion and create key // TODO: Set it in Terraform
Use ccplus-container-apps-environment-{env}, ccplus-container-apps-log-analytics-workspace-{env} for projects of Corporate Payment & Travel
need to set the key of app-registraion into keyvault as microsoft-provider-authentication-secret-container

## initial local

terraform init -backend-config=./backends/dev/dev.local.backend.hcl

## initial dev

terraform init -backend-config=./backends/dev/dev.backend.hcl

## commands to deploy dev

    terraform init -backend-config=./backends/dev/dev.backend.hcl -reconfigure
    terraform validate
    terraform plan -var-file=./environments/dev/dev.tfvars -out=theplan.txt -lock=false
    terraform apply theplan.txt
    terraform destroy

## commands to deploy prod

    terraform init -backend-config=./backends/prod/prod.backend.hcl -reconfigure
    terraform validate
    terraform plan -var-file=./environments/prod/prod.tfvars -out=theplan.txt -lock=false
    terraform apply theplan.txt
    terraform destroy

## set the cosmosdb

Terraform can create only resource so, need to create collections what you need manually

## set keyvault variables

Create Azure Service Bus endpoints manually

## set deployment center for Azure Function

Set the settings manually
Set the Authentication manually

import Hapi, { Server } from "@hapi/hapi";
import { ensureEnv } from "./env.helper";

import initializeServices from "./src/services";
import createRoutes from "./src/routes";

export let server: Server;

export const init = async function (options) {
    // Checke Environment Variables
    ensureEnv();

    server = Hapi.server({
        debug: {
            request: ["error"],
        },
        port: options.port,
        host: "0.0.0.0",
    });

    const services = await initializeServices();
    const routes = await createRoutes(services);
    server.route(routes);

    // Add the routes
    server.route({
        method: "GET",
        path: "/ping",
        options: {
            auth: false,
        },
        handler: function (request, h) {
            return "pong";
        },
    });

    server.route({
        method: "GET",
        path: "/{any*}",
        handler: function (request, h) {
            return h.response("Not found").code(404);
        },
    });

    return server;
};

export const start = async function () {
    console.log(`Listening on ${server.settings.host}:${server.settings.port}`);
    return server.start();
};

let exiting: boolean = false;

function exitHandler(exitCode?: number) {
    return function () {
        if (exiting || !server) return;
        exiting = true;
        console.log("\nServer shutting down... ");
        server
            .stop()
            .then((_) => console.log("Shutdown successfully"))
            .then((_) => process.exit(exitCode))
            .catch((_) => process.exit(-2));
    };
}

process.on("exit", exitHandler());
process.on("SIGINT", exitHandler());
process.on("uncaughtException", exitHandler());

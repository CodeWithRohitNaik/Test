const { SecretClient } = require("@azure/keyvault-secrets");
const { DefaultAzureCredential } = require("@azure/identity");

const requiredEnvList = [
    "APPLICATION_INSIGHTS_KEY",
    "MQTT_HOST_URL",
    "MQTT_PORT",
    "MQTT_PROTOCOL",
    "MQTT_KEY",
    "MQTT_CERT",
    "DOCUMENT_DB_ENDPOINT",
    "DOCUMENT_DATABASE_ID",
];

module.exports.ensureEnv = function (envList) {
    const errors = [];
    if (!envList) {
        envList = requiredEnvList;
    }
    for (let a of envList) {
        if (!process.env[a]) errors.push(`"${a}" must be defined`);
    }
    if (errors.length > 0) {
        console.error(`Environment variables missing:\n ${errors.join(", ")}`);
        throw new Error("Environment variables missing!\n\t-> " + errors.join("\n\t-> "));
    }
};

module.exports.populateEnvFromKeyVault = async function (keyvaultName) {
    //authenticates using az credentials or system assigned credentials
    const credential = new DefaultAzureCredential();
    const url = "https://" + keyvaultName + ".vault.azure.net";
    const client = new SecretClient(url, credential);

    for (let a of requiredEnvList) {
        // Keyvault secrets can't contain underscores('_') so secrets are stored with dashes('-')
        console.log(`Getting secret ${a.replaceAll("_", "-")} from keyvault`);
        let secret = await client.getSecret(a.replaceAll("_", "-"));
        process.env[a] = secret.value;
    }
};

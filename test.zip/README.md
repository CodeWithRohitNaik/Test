# A2B Pay Cloud API

This is the recommended way to run the A2B Pay Cloud API for local development.

## Node version

```sh
v22.12.0
```

## Run project with docker-compose (Recommended)

Go to the project directory and run the command.(Ensure there is a `.env` file in the root directory with necessary enironment variables.)

```sh
docker compose up
```

## Docker Installation

For mac : https://docs.docker.com/desktop/install/mac-install/
For windows : https://docs.docker.com/desktop/install/windows-install/

Run docker container from the docker image. Note: need to have the environment variables defined before running the container. Change the location of the environment variable file below command to match yours:

import Joi from "joi";

export const postEventSchema = Joi.object({
    eventType: Joi.string().required().messages({
        "string.base": `eventType should be a type of 'text'`,
        "string.empty": `eventType cannot be an empty field`,
        "any.required": `eventType is a required field`,
    }),
    eventTime: Joi.string().required().messages({
        "string.base": `eventTime should be a type of 'text'`,
        "string.empty": `eventTime cannot be an empty field`,
        "any.required": `eventTime is a required field`,
    }),
    dispatchDeviceId: Joi.string().optional().messages({
        "string.base": `dispatchDeviceId should be a type of 'text'`,
    }),
    details: Joi.object({
        driverId: Joi.string().optional().messages({
            "string.base": `driverId should be a type of 'text'`,
        }),
        meterId: Joi.string().optional().messages({
            "string.base": `meterId should be a type of 'text'`,
        }),
    }),
});

const Joi = require("joi").extend(require("@joi/date"));

const Vehicle = Joi.object({
    registrationPlate: Joi.string().trim().required().messages({
        "string.base": `registrationPlate should be a type of 'text'`,
        "string.empty": `registrationPlate cannot be an empty field`,
        "any.required": `registrationPlate is a required field`,
    }),
    watModified: Joi.boolean().required().messages({
        "boolean.base": `watModified should be a type of 'boolean'`,
        "any.required": `watModified is a required field`,
    }),
    vehicleStatus: Joi.string()
        .valid("Installing", "Installed", "Operational", "Dormant", "Uninstalling", "Uninstalled")
        .required()
        .messages({
            "string.base": `vehicleStatus should be a type of 'text'`,
            "any.only": `vehicleStatus must be one of Installing, Installed, Operational, Dormant, Uninstalling, Uninstalled`,
            "any.required": `vehicleStatus is a required field`,
        }),
    vehicleId: Joi.string().trim().required().messages({
        "string.base": `vehicleId should be a type of 'text'`,
        "string.empty": `vehicleId cannot be an empty field`,
        "any.required": `vehicleId is a required field`,
    }),
});

const Driver = Joi.object({
    tssAuthorisationNumber: Joi.string().trim().required().messages({
        "string.base": `tssAuthorisationNumber should be a type of 'text'`,
        "string.empty": `tssAuthorisationNumber cannot be an empty field`,
        "any.required": `tssAuthorisationNumber is a required field`,
    }),
    abn: Joi.string().trim().required().messages({
        "string.base": `abn should be a type of 'text'`,
        "string.empty": `abn cannot be an empty field`,
        "any.required": `abn is a required field`,
    }),
    dispatchDriverId: Joi.string().trim().optional().messages({
        "string.base": `dispatchDriverId should be a type of 'text'`,
    }),
    dispatchShiftId: Joi.string().trim().optional().messages({
        "string.base": `dispatchShiftId should be a type of 'text'`,
    }),
});

const Meter = Joi.object({
    meterManufacturer: Joi.string().trim().required().messages({
        "string.base": `meterManufacturer should be a type of 'text'`,
        "string.empty": `meterManufacturer cannot be an empty field`,
        "any.required": `meterManufacturer is a required field`,
    }),
    meterStatus: Joi.string().trim().optional().messages({
        "string.base": `meterStatus should be a type of 'text'`,
    }),
    meterModel: Joi.string().trim().optional().messages({
        "string.base": `meterModel should be a type of 'text'`,
    }),
    meterSoftwareVersion: Joi.string().trim().optional().messages({
        "string.base": `meterSoftwareVersion should be a type of 'text'`,
    }),
    meterId: Joi.string().trim().required().messages({
        "string.base": `meterId should be a type of 'text'`,
        "string.empty": `meterId cannot be an empty field`,
        "any.required": `meterId is a required field`,
    }),
    meterType: Joi.string().valid("SoftMeter", "HardWired").required().messages({
        "string.base": `meterType should be a type of 'text'`,
        "any.only": `meterType must be one of SoftMeter, HardWired`,
        "any.required": `meterType is a required field`,
    }),
});

const Dispatch = Joi.object({
    dispatchManufacturer: Joi.string().trim().required().messages({
        "string.base": `dispatchManufacturer should be a type of 'text'`,
        "string.empty": `dispatchManufacturer cannot be an empty field`,
        "any.required": `dispatchManufacturer is a required field`,
    }),
    dispatchModel: Joi.string().trim().required().messages({
        "string.base": `dispatchModel should be a type of 'text'`,
        "string.empty": `dispatchModel cannot be an empty field`,
        "any.required": `dispatchModel is a required field`,
    }),
    dispatchSoftwareVersion: Joi.string().trim().required().messages({
        "string.base": `dispatchSoftwareVersion should be a type of 'text'`,
        "string.empty": `dispatchSoftwareVersion cannot be an empty field`,
        "any.required": `dispatchSoftwareVersion is a required field`,
    }),
    dispatchDeviceId: Joi.string().trim().required().messages({
        "string.base": `dispatchDeviceId should be a type of 'text'`,
        "string.empty": `dispatchDeviceId cannot be an empty field`,
        "any.required": `dispatchDeviceId is a required field`,
    }),
    dispatchSystemId: Joi.string().trim().optional().messages({
        "string.base": `dispatchSystemId should be a type of 'text'`,
    }),
});

const GPS = Joi.object({
    lat: Joi.number().required().messages({
        "number.base": `lat should be a type of 'number'`,
        "any.required": `lat is a required field`,
    }),
    lon: Joi.number().required().messages({
        "number.base": `lon should be a type of 'number'`,
        "any.required": `lon is a required field`,
    }),
    shortDescription: Joi.string().trim().optional().messages({
        "string.base": `shortDescription should be a type of 'text'`,
    }),
    timestampIso: Joi.date().iso().optional().messages({
        "date.base": `timestampIso should be a valid date`,
        "date.format": `timestampIso must be in ISO format`,
    }),
});

const Fare = Joi.object({
    isMetered: Joi.boolean().required().messages({
        "boolean.base": `isMetered should be a type of 'boolean'`,
        "any.required": `isMetered is a required field`,
    }),
    isBooked: Joi.boolean().required().messages({
        "boolean.base": `isBooked should be a type of 'boolean'`,
        "any.required": `isBooked is a required field`,
    }),
    isPrepayment: Joi.boolean().required().messages({
        "boolean.base": `isPrepayment should be a type of 'boolean'`,
        "any.required": `isPrepayment is a required field`,
    }),
    metersTravelled: Joi.number().optional().messages({
        "number.base": `metersTravelled should be a type of 'number'`,
    }),
    startTimeIso: Joi.date().iso().required().messages({
        "date.base": `startTimeIso should be a valid date`,
        "date.format": `startTimeIso must be in ISO format`,
        "any.required": `startTimeIso is a required field`,
    }),
    // TODO: It is not required for prepayment
    endTimeIso: Joi.date().iso().optional().messages({
        "date.base": `endTimeIso should be a valid date`,
        "date.format": `endTimeIso must be in ISO format`,
    }),
    requestedAmountCents: Joi.number().integer().required().messages({
        "number.base": `requestedAmountCents should be a type of 'number'`,
        "any.required": `requestedAmountCents is a required field`,
    }),
    flagFallAmountCents: Joi.number()
        .integer()
        .when("isMetered", {
            is: true,
            then: Joi.required(),
            otherwise: Joi.optional(),
        })
        .messages({
            "number.base": `flagFallAmountCents should be a type of 'number'`,
        }),
    meteredAmountCents: Joi.number()
        .integer()
        .when("isMetered", {
            is: true,
            then: Joi.required(),
            otherwise: Joi.optional(),
        })
        .messages({
            "number.base": `meteredAmountCents should be a type of 'number'`,
        }),
    meterExtrasCents: Joi.number().integer().optional().messages({
        "number.base": `meterExtrasCents should be a type of 'number'`,
    }),
    richTripDataUrl: Joi.string().uri().allow("").optional().messages({
        "string.base": `richTripDataUrl should be a valid URI`,
    }),
    // TODO: Required for Closed loop cards
    pickUpGps: GPS.required().messages({
        "object.base": `pickUpGps must be an object`,
        "any.required": `pickUpGps is a required field`,
    }),
    // TODO: Required for Closed loop cards
    dropOffGps: GPS.required().messages({
        "object.base": `dropOffGps must be an object`,
        "any.required": `dropOffGps is a required field`,
    }),
    // TODO: Required for Closed loop cards
    waypoints: Joi.array().items(GPS).optional().messages({
        "array.base": `waypoints should be an array`,
    }),
    // TODO: Required for TSS
    tariffs: Joi.array()
        .items(
            Joi.object({
                id: Joi.string().trim().required().messages({
                    "string.base": `id should be a type of 'text'`,
                    "string.empty": `id cannot be an empty field`,
                    "any.required": `id is a required field`,
                }),
                name: Joi.string().trim().optional().messages({
                    "string.base": `name should be a type of 'text'`,
                }),
                description: Joi.string().trim().optional().messages({
                    "string.base": `description should be a type of 'text'`,
                }),
                flagfallAmountCents: Joi.number().integer().optional().messages({
                    "number.base": `flagfallAmountCents should be a type of 'number'`,
                }),
            })
        )
        .optional()
        .messages({
            "array.base": `tariffs should be an array`,
        }),
});

const Levy = Joi.object({
    name: Joi.string().trim().required().messages({
        "string.base": `name should be a type of 'text'`,
        "string.empty": `name cannot be an empty field`,
        "any.required": `name is a required field`,
    }),
    amountCents: Joi.number().integer().required().messages({
        "number.base": `amountCents should be a type of 'number'`,
        "any.required": `amountCents is a required field`,
    }),
    automaticallyApplied: Joi.boolean().required().messages({
        "boolean.base": `automaticallyApplied should be a type of 'boolean'`,
        "any.required": `automaticallyApplied is a required field`,
    }),
    amountPreset: Joi.boolean().required().messages({
        "boolean.base": `amountPreset should be a type of 'boolean'`,
        "any.required": `amountPreset is a required field`,
    }),
});

const ExtendedFare = Joi.object({
    tolls: Joi.array()
        .items(
            Joi.object({
                name: Joi.string().trim().required().messages({
                    "string.base": `name should be a type of 'text'`,
                    "string.empty": `name cannot be an empty field`,
                    "any.required": `name is a required field`,
                }),
                amountCents: Joi.number().integer().required().messages({
                    "number.base": `amountCents should be a type of 'number'`,
                    "any.required": `amountCents is a required field`,
                }),
                automaticallyApplied: Joi.boolean().required().messages({
                    "boolean.base": `automaticallyApplied should be a type of 'boolean'`,
                    "any.required": `automaticallyApplied is a required field`,
                }),
                amountPreset: Joi.boolean().required().messages({
                    "boolean.base": `amountPreset should be a type of 'boolean'`,
                    "any.required": `amountPreset is a required field`,
                }),
                entryGantryWaypoint: Joi.object({
                    lat: Joi.number().required().messages({
                        "number.base": `lat should be a type of 'number'`,
                        "any.required": `lat is a required field`,
                    }),
                    lon: Joi.number().required().messages({
                        "number.base": `lon should be a type of 'number'`,
                        "any.required": `lon is a required field`,
                    }),
                })
                    .optional()
                    .messages({
                        "object.base": `entryGantryWaypoint must be an object`,
                    }),
                exitGantryWaypoint: Joi.object({
                    lat: Joi.number().required().messages({
                        "number.base": `lat should be a type of 'number'`,
                        "any.required": `lat is a required field`,
                    }),
                    lon: Joi.number().required().messages({
                        "number.base": `lon should be a type of 'number'`,
                        "any.required": `lon is a required field`,
                    }),
                })
                    .optional()
                    .messages({
                        "object.base": `exitGantryWaypoint must be an object`,
                    }),
            })
        )
        .optional()
        .messages({
            "array.base": `tolls should be an array`,
        }),
    levies: Joi.array().items(Levy).optional().messages({
        "array.base": `levies should be an array`,
    }),
    extras: Joi.array().items(Levy).optional().messages({
        "array.base": `extras should be an array`,
    }),
    other: Joi.array().items(Levy).optional().messages({
        "array.base": `other should be an array`,
    }),
});

export const postPaymentSchema = Joi.object({
    id: Joi.string().trim().required().messages({
        "string.base": `id should be a type of 'text'`,
        "string.empty": `id cannot be an empty field`,
        "any.required": `id is a required field`,
    }),
    type: Joi.string().trim().required().messages({
        "string.base": `type should be a type of 'text'`,
        "string.empty": `type cannot be an empty field`,
        "any.required": `type is a required field`,
    }),
    localTimeIso: Joi.date().iso().required().messages({
        "date.base": `localTimeIso should be a valid date`,
        "date.format": `localTimeIso must be in ISO format`,
        "any.required": `localTimeIso is a required field`,
    }),
    version: Joi.string().trim().required().messages({
        "string.base": `version should be a type of 'text'`,
        "string.empty": `version cannot be an empty field`,
        "any.required": `version is a required field`,
    }),
    data: Joi.object({
        tripId: Joi.string().trim().required().messages({
            "string.base": `tripId should be a type of 'text'`,
            "string.empty": `tripId cannot be an empty field`,
            "any.required": `tripId is a required field`,
        }),
        // TODO: TripNumber or BookingId is required to be present to print in EOS and Partner Portal
        tripNumber: Joi.string().trim().messages({
            "string.base": `tripNumber should be a type of 'text'`,
        }),
        // TODO: TripNumber or BookingId is required to be present to print in EOS and Partner Portal
        bookingId: Joi.string().trim().messages({
            "string.base": `bookingId should be a type of 'text'`,
        }),
        merchantId: Joi.string().trim().required().messages({
            "string.base": `merchantId should be a type of 'text'`,
            "string.empty": `merchantId cannot be an empty field`,
            "any.required": `merchantId is a required field`,
        }),
        isPartial: Joi.boolean().messages({
            "boolean.base": `isPartial should be a type of 'boolean'`,
        }),
        dispatchHandlesPartial: Joi.boolean().messages({
            "boolean.base": `dispatchHandlesPartial should be a type of 'boolean'`,
        }),
        vehicle: Vehicle.required().messages({
            "object.base": `vehicle must be an object`,
            "any.required": `vehicle is a required field`,
        }),
        driver: Driver.required().messages({
            "object.base": `driver must be an object`,
            "any.required": `driver is a required field`,
        }),
        meter: Meter.required().messages({
            "object.base": `meter must be an object`,
            "any.required": `meter is a required field`,
        }),
        dispatch: Dispatch.required().messages({
            "object.base": `dispatch must be an object`,
            "any.required": `dispatch is a required field`,
        }),
        fare: Fare.required().messages({
            "object.base": `fare must be an object`,
            "any.required": `fare is a required field`,
        }),
        extendedFare: ExtendedFare.optional().messages({
            "object.base": `extendedFare must be an object`,
        }),
    })
        .required()
        .messages({
            "object.base": `data must be an object`,
            "any.required": `data is a required field`,
        }),
});

const dispatchId = {
    dispatchId: Joi.string().required().messages({
        "string.base": `dispatchId should be a type of 'text'`,
        "string.empty": `dispatchId cannot be an empty field`,
        "any.required": `dispatchId is a required field`,
    }),
};

const paymentRequestId = {
    paymentRequestId: Joi.string()
        .guid({ version: ["uuidv4"] })
        .required()
        .messages({
            "string.base": `paymentRequestId should be a type of 'text'`,
            "string.guid": `paymentRequestId must be a valid UUID`,
            "string.empty": `paymentRequestId cannot be an empty field`,
            "any.required": `paymentRequestId is a required field`,
        }),
};

export const getPaymentSchema = Joi.object({
    ...dispatchId,
    ...paymentRequestId,
});

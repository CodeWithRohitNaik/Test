const Joi = require("joi").extend(require("@joi/date"));

const dispatchId = {
    dispatchId: Joi.string().valid("MTI", "ICABBI", "AUTOCAB", "RYDEWIZARD").insensitive().required().messages({
        "string.base": `dispatchId should be a type of 'text'`,
        "string.empty": `dispatchId cannot be an empty field`,
        "any.required": `dispatchId is a required field`,
    }),
};

const dispatchDeviceId = {
    dispatchDeviceId: Joi.string().required().messages({
        "string.base": `dispatchDeviceId should be a type of 'text'`,
        "string.empty": `dispatchDeviceId cannot be an empty field`,
        "any.required": `dispatchDeviceId is a required field`,
    }),
};

const terminalSerialId = {
    terminalSerialId: Joi.string().required().messages({
        "string.base": `terminalSerialId should be a type of 'text'`,
        "string.empty": `terminalSerialId cannot be an empty field`,
        "any.required": `terminalSerialId is a required field`,
    }),
};

const terminalId = {
    dispatchId: Joi.string().allow(null),
};

const pairingCode = {
    pairingCode: Joi.string().length(6).pattern(/^\d+$/).required().messages({
        "string.base": "The input should be a string.",
        "string.length": "The input must be exactly 6 digits long.",
        "string.pattern.base": "The input must contain only digits.",
        "any.required": "The input is required.",
    }),
};

export const getPairingSchema = Joi.object({
    ...dispatchId,
    ...dispatchDeviceId,
    ...terminalSerialId,
});

export const postPairingParamSchema = Joi.object({
    ...dispatchId,
});

export const postPairingPayloadSchema = Joi.object({
    ...dispatchDeviceId,
    ...terminalSerialId,
    ...terminalId,
});

export const deletePairingParamSchema = Joi.object({
    ...dispatchId,
});

export const deletePairingPayloadSchema = Joi.object({
    ...dispatchDeviceId,
    ...terminalSerialId,
});

export const postVerifyParamSchema = Joi.object({
    ...dispatchId,
});

export const postVerifyPayloadSchema = Joi.object({
    ...dispatchDeviceId,
    ...terminalSerialId,
    ...pairingCode,
});

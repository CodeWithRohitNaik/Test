const Joi = require("joi").extend(require("@joi/date"));

import { WebhookEventTypeEnum } from "@src/models";

// TODO: Add more validation for the webhook schema
const EventType = Joi.string()
    .valid(WebhookEventTypeEnum.PAYMENT_CREATED, WebhookEventTypeEnum.PAYMENT_FAILED, WebhookEventTypeEnum.PAYMENT_RESPONSE)
    .insensitive()
    .required();

export const getWebhookSchema = Joi.object({
    webhookId: Joi.string().trim().guid().required().messages({
        "string.base": `webhookId should be a type of 'guid'`,
        "string.empty": `webhookId cannot be an empty field`,
        "any.required": `webhookId is a required field`,
    }),
});

export const deleteWebhookSchema = Joi.object({
    webhookId: Joi.string().trim().guid().required().messages({
        "string.base": `webhookId should be a type of 'guid'`,
        "string.empty": `webhookId cannot be an empty field`,
        "any.required": `webhookId is a required field`,
    }),
});

export const registerWebhookSchema = Joi.object({
    url: Joi.string()
        .uri({ scheme: ["http", "https"] })
        .trim()
        .required()
        .messages({
            "string.base": `url should be a type of 'text'`,
            "string.empty": `url cannot be an empty field`,
            "any.required": `url is a required field`,
        }),
    eventTypes: Joi.array().items(EventType).required(),
});

export const registerWebhookParamSchema = Joi.object({
    dispatchId: Joi.string().trim().required().messages({
        "string.base": `dispatchId should be a type of 'text'`,
        "string.empty": `dispatchId cannot be an empty field`,
        "any.required": `dispatchId is a required field`,
    }),
});

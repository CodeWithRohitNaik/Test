const Joi = require("joi").extend(require("@joi/date"));

const locationSchema = Joi.object({
    latitude: Joi.string().required(),
    longitude: Joi.string().required(),
});

const dispatchId = {
    dispatchId: Joi.string().required().messages({
        "string.base": `dispatchId should be a type of 'text'`,
        "string.empty": `dispatchId cannot be an empty field`,
        "any.required": `dispatchId is a required field`,
    }),
};

const preauthRequestId = {
    paymentRequestId: Joi.string()
        .guid({ version: ["uuidv4"] })
        .required()
        .messages({
            "string.base": `preauthRequestId should be a type of 'text'`,
            "string.guid": `preauthRequestId must be a valid UUID`,
            "string.empty": `preauthRequestId cannot be an empty field`,
            "any.required": `preauthRequestId is a required field`,
        }),
};

export const postPreauthSchema = Joi.object({
    preauthRequestId: Joi.string().guid({ version: "uuidv4" }).optional(),
    senderDeviceId: Joi.string().required(),
    requestedAmountCents: Joi.number().integer().required(),
    currencyCode: Joi.string().required(),
    bookingId: Joi.string().optional(),
    pickUpLocation: locationSchema.optional(),
    dropOffLocation: locationSchema.optional(),
    localTimeIso: Joi.string().isoDate().required(),
});

export const getPreauthSchema = Joi.object({
    ...dispatchId,
    ...preauthRequestId,
});
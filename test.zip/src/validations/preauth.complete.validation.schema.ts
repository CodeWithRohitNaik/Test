import Joi from "joi";

const gpsSchema = Joi.object({
    latitude: Joi.string().required(),
    longitude: Joi.string().required(),
    fixLocalTimeIso: Joi.string().isoDate().required(),
});
const waypointSchema = gpsSchema;

const tariffSchema = Joi.object({
    number: Joi.string().required(),
    description: Joi.string().required(),
});
const fareSchema = Joi.object({
    isMetered: Joi.boolean().required(),
    isBooked: Joi.boolean().required(),
    metersTravelled: Joi.number().required(),
    startTimeIso: Joi.string().isoDate().required(),
    endTimeIso: Joi.string().isoDate().required(),
    meteredAmountCents: Joi.number().required(),
    meterExtrasCents: Joi.number().required(),
    richTripDataUrl: Joi.string().optional(),
    pickUpGps: gpsSchema.optional(),
    dropOffGps: gpsSchema.optional(),
    waypoints: Joi.array().items(waypointSchema).required(),
    tariffs: Joi.array().items(tariffSchema).required(),
});
const gantryWaypointSchema = Joi.object({
    latitude: Joi.string().required(),
    longitude: Joi.string().required(),
});
const tollSchema = Joi.object({
    description: Joi.string().required(),
    amountCents: Joi.string().required(),
    automaticallyApplied: Joi.boolean().required(),
    amountPreset: Joi.boolean().required(),
    entryGantryWaypoint: gantryWaypointSchema.required(),
    exitGantryWaypoint: gantryWaypointSchema.required(),
});
const levySchema = Joi.object({
    description: Joi.string().required(),
    amountCents: Joi.string().required(),
    automaticallyApplied: Joi.boolean().required(),
    amountPreset: Joi.boolean().required(),
});

const extraSchema = Joi.object({
    description: Joi.string().required(),
    amountCents: Joi.string().required(),
    automaticallyApplied: Joi.boolean().required(),
    amountPreset: Joi.boolean().required(),
});
const otherSchema = Joi.object({
    description: Joi.string().required(),
    amountCents: Joi.string().required(),
    automaticallyApplied: Joi.boolean().required(),
    amountPreset: Joi.boolean().required(),
});
const extendedFareSchema = Joi.object({
    tripNumber: Joi.string().optional(),
    bookingID: Joi.string().optional(),
    flagFallCents: Joi.number().required(),
    meteredAmountCents: Joi.number().required(),
    tolls: Joi.array().items(tollSchema).required(),
    levies: Joi.array().items(levySchema).required(),
    extras: Joi.array().items(extraSchema).required(),
    other: Joi.array().items(otherSchema).required(),
});
const vehicleSchema = Joi.object({
    registrationPlate: Joi.string().required(),
    watModified: Joi.boolean().required(),
    vehicleStatus: Joi.string().required(),
    vehicleId: Joi.string().required(),
});
const dispatchSchema = Joi.object({
    dispatchManufacturer: Joi.string().required(),
    dispatchModel: Joi.string().required(),
    dispatchSoftwareVersion: Joi.string().required(),
    dispatchDeviceId: Joi.string().required(),
});
const driverSchema = Joi.object({
    authorisation: Joi.string().required(),
    abn: Joi.string().required(),
    dispatchId: Joi.string().optional(),
    dispatchShiftId: Joi.string().optional(),
});
export const postPreauthCompleteSchema = Joi.object({
    preauthPayments: Joi.array()
        .items(
            Joi.object({
                preauthToken: Joi.string().optional(),
                preauthRequestId: Joi.string().optional(),
            })
        )
        .optional(),
    bookingId: Joi.string().optional(),
    tripId: Joi.string().optional(),
    localTimeIso: Joi.string().isoDate().required(),
    fare: fareSchema.required(),
    extendedFare: extendedFareSchema.optional(),
    vehicle: vehicleSchema.required(),
    dispatch: dispatchSchema.required(),
    driver: driverSchema.required(),
});

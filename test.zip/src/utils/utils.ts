import moment from "moment-timezone";

function parseJSONString(jsonString: string) {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        return {};
    }
}

function getSydneyDateTimeIso() {
    return moment(new Date()).tz("Australia/Sydney").toISOString();
}

function getUtcDateTimeIso() {
    return moment.utc().toISOString();
}

function getLocalDateTimeIsoWithFormat() {
    return moment().format("YYYY-MM-DDTHH:mm:ss.SSSSSSSZ");
}

function getLpadWithZero(value: string, length: number) {
    return value.toString().padStart(length, "0");
}

function mapKeysToLowercase(payload: any): any {
    if (Array.isArray(payload)) {
        return payload.map(mapKeysToLowercase);
    } else if (payload !== null && typeof payload === "object") {
        return Object.keys(payload).reduce((acc, key) => {
            let newKey = key;

            // Special cases for WATModified and ABN
            if (key === "WATModified") {
                newKey = "watModified";
            } else if (key === "ABN") {
                newKey = "abn";
            } else {
                newKey = key.charAt(0).toLowerCase() + key.slice(1);
            }

            acc[newKey] = mapKeysToLowercase(payload[key]);
            return acc;
        }, {} as any);
    }
    return payload;
}

function getStringsByArray(array: string[]): string {
    return array.join(", ");
}

function removeUnderscoreFields(obj: any): any {
    if (Array.isArray(obj)) {
        return obj.map(removeUnderscoreFields);
    } else if (obj !== null && typeof obj === "object") {
        return Object.keys(obj).reduce((acc, key) => {
            if (!key.startsWith("_")) {
                acc[key] = removeUnderscoreFields(obj[key]);
            }
            return acc;
        }, {} as any);
    }
    return obj;
}

export {
    parseJSONString,
    getSydneyDateTimeIso,
    getUtcDateTimeIso,
    getLpadWithZero,
    mapKeysToLowercase,
    getStringsByArray,
    removeUnderscoreFields,
    getLocalDateTimeIsoWithFormat,
};

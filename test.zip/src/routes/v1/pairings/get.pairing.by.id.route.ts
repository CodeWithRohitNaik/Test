import { BAD_REQUEST, NOT_FOUND_PAIRING } from "@src/models/response.constants";
import { ErrorDetail, ResponseErrorModel } from "@src/models/response.error.model";
import { RouteConfig } from "@src/models/route.config";
import { PairingService } from "@src/services/v1/pairing.service";
import { removeUnderscoreFields } from "@src/utils/utils";
import * as pairingSchema from "@src/validations/pairing.validation.schema";
import * as appInsights from "applicationinsights";

export const getById = async (pairingService: PairingService): Promise<RouteConfig> => {
    if (!pairingService) {
        throw new Error("PairingService must be passed in");
    }
    return {
        description: "Get pairing by id",
        notes: ["Get pairing by id"],
        validate: {
            failAction: async (request, h, error: any) => {
                const errorDetails = error.details.map((detail: any) => new ErrorDetail("", "", detail.message));
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { transaction: request.payload },
                });

                const errorMessage = {
                    error: new ResponseErrorModel(BAD_REQUEST.responseCode, BAD_REQUEST.message, "", errorDetails),
                };
                return h.response(errorMessage).code(BAD_REQUEST.httpStatusCode).takeover();
            },
            params: pairingSchema.getPairingSchema,
            options: {
                allowUnknown: true,
                abortEarly: false,
            },
        },
        tags: ["api"],
        handler: async (request, h) => {
            try {
                const { dispatchId, dispatchDeviceId, terminalSerialId } = request.params as {
                    dispatchId: string;
                    dispatchDeviceId: string;
                    terminalSerialId: string;
                };
                const result = await pairingService.getByPairingIds(dispatchId, dispatchDeviceId, terminalSerialId);
                if (result.length === 0) {
                    const errorMessage = {
                        error: new ResponseErrorModel(NOT_FOUND_PAIRING.responseCode, NOT_FOUND_PAIRING.message),
                    };
                    return h.response(errorMessage).code(NOT_FOUND_PAIRING.httpStatusCode);
                }
                return h.response(removeUnderscoreFields(result[0])).code(200);
            } catch (error: any) {
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { ...error },
                });

                const message = error.message;
                if (message?.errorCode) {
                    const errorMessage = { error: new ResponseErrorModel(message.errorCode, message.errorMessage) };
                    return h.response(errorMessage).code(message.httpStatusCode);
                } else {
                    throw new Error("internal error");
                }
            }
        },
    };
};

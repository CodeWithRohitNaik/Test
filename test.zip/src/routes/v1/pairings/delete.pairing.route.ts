import { PairingStatusEnum } from "@src/models/enums";
import { PairingTable } from "@src/models/pairing.db.model";
import { BAD_REQUEST, NOT_FOUND_PAIRING } from "@src/models/response.constants";
import { ErrorDetail, ResponseErrorModel } from "@src/models/response.error.model";
import { RouteConfig } from "@src/models/route.config";
import { PairingService } from "@src/services/v1/pairing.service";
import { MqttBrokerService } from "@src/shared/services/mqtt.broker.service";
import * as pairingSchema from "@src/validations/pairing.validation.schema";
import * as appInsights from "applicationinsights";

export const deletePairing = async (
    pairingService: PairingService,
    mqttBrokerService: MqttBrokerService
): Promise<RouteConfig> => {
    return {
        description: "Delete a pairing",
        notes: ["Delete a pairing"],
        validate: {
            failAction: async (request, h, error: any) => {
                const errorDetails = error.details.map((detail: any) => new ErrorDetail("", "", detail.message));
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { transaction: request.payload },
                });

                const errorMessage = {
                    error: new ResponseErrorModel(BAD_REQUEST.responseCode, BAD_REQUEST.message, "", errorDetails),
                };
                return h.response(errorMessage).code(BAD_REQUEST.httpStatusCode).takeover();
            },
            params: pairingSchema.deletePairingParamSchema,
            payload: pairingSchema.deletePairingPayloadSchema,
            options: {
                allowUnknown: true,
                abortEarly: false,
            },
        },
        tags: ["api"],
        handler: async (request, h) => {
            const mqttMessageVersion = "1.0";

            appInsights.defaultClient.trackEvent({
                name: "Delete pairing request received",
                properties: request.payload as object,
            });
            try {
                const { dispatchId } = request.params as { dispatchId: string };
                const { dispatchDeviceId, terminalSerialId } = request.payload as {
                    dispatchDeviceId: string;
                    terminalSerialId: string;
                };

                const result = await pairingService.getByPairingIds(dispatchId, dispatchDeviceId, terminalSerialId);
                if (result.length === 0) {
                    const errorMessage = {
                        error: new ResponseErrorModel(NOT_FOUND_PAIRING.responseCode, NOT_FOUND_PAIRING.message),
                    };
                    return h.response(errorMessage).code(NOT_FOUND_PAIRING.httpStatusCode);
                }

                const pairingFromDb = result[0];
                await pairingService.delete(pairingFromDb.id, pairingFromDb.dispatchId);

                const { topicTemplate, topicBody } = pairingService.getPairingTopicBody(
                    pairingFromDb,
                    mqttMessageVersion,
                    false
                );
                await mqttBrokerService.sendMessageToMQTTTopic(topicTemplate, JSON.stringify(topicBody), "");

                appInsights.defaultClient.trackEvent({
                    name: "Sent unpairing-request to terminal",
                    properties: {
                        topicTemplate,
                        ...topicBody,
                    },
                });

                return h.response().code(200);
            } catch (error: any) {
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { ...error },
                });

                const message = error.message;
                if (message?.errorCode) {
                    const errorMessage = { error: new ResponseErrorModel(message.errorCode, message.errorMessage) };
                    return h.response(errorMessage).code(message.httpStatusCode);
                } else {
                    throw new Error("internal error");
                }
            }
        },
    };
};

import { PairingStatusEnum } from "@src/models/enums";
import { PairingTable } from "@src/models/pairing.db.model";
import { BAD_REQUEST } from "@src/models/response.constants";
import { ErrorDetail, ResponseErrorModel } from "@src/models/response.error.model";
import { RouteConfig } from "@src/models/route.config";
import { PairingService } from "@src/services/v1/pairing.service";
import { MqttBrokerService } from "@src/shared/services/mqtt.broker.service";
import * as pairingSchema from "@src/validations/pairing.validation.schema";
import * as appInsights from "applicationinsights";
import { v4 as uuidv4 } from "uuid";

export const createPairing = async (
    pairingService: PairingService,
    mqttBrokerService: MqttBrokerService
): Promise<RouteConfig> => {
    return {
        description: "Create a new pairing",
        notes: ["Create a new pairing"],
        validate: {
            failAction: async (request, h, error: any) => {
                const errorDetails = error.details.map((detail: any) => new ErrorDetail("", "", detail.message));
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { transaction: request.payload },
                });

                const errorMessage = {
                    error: new ResponseErrorModel(BAD_REQUEST.responseCode, BAD_REQUEST.message, "", errorDetails),
                };
                return h.response(errorMessage).code(BAD_REQUEST.httpStatusCode).takeover();
            },
            params: pairingSchema.postPairingParamSchema,
            payload: pairingSchema.postPairingPayloadSchema,
            options: {
                allowUnknown: true,
                abortEarly: false,
            },
        },
        tags: ["api"],
        handler: async (request, h) => {
            const mqttMessageVersion = "1.0";

            appInsights.defaultClient.trackEvent({
                name: "Pairing request received",
                properties: request.payload as object,
            });
            try {
                const { dispatchId } = request.params as { dispatchId: string };
                const { dispatchDeviceId, terminalSerialId, terminalId } = request.payload as {
                    dispatchDeviceId: string;
                    terminalSerialId: string;
                    terminalId: string;
                };

                const result = await pairingService.getByPairingIds(dispatchId, dispatchDeviceId, terminalSerialId);
                if (result.length > 0) {
                    return h.response({ terminalpairedCode: result[0].terminalpairedCode }).code(200);
                }

                const newPairing: PairingTable = {
                    id: uuidv4(),
                    dispatchId,
                    dispatchDeviceId,
                    terminalSerialId,
                    terminalId,
                    terminalpairedCode: "", // Will be updated after pairing is successful, which will be update by MQTT Message
                    createdAt: new Date(),
                    updatedAt: new Date(),
                    status: PairingStatusEnum.INACTIVE,
                };
                await pairingService.create(newPairing);

                const { topicTemplate, topicBody } = pairingService.getPairingTopicBody(newPairing, mqttMessageVersion);
                await mqttBrokerService.sendMessageToMQTTTopic(topicTemplate, JSON.stringify(topicBody), "");

                appInsights.defaultClient.trackEvent({
                    name: "Sent pairing-request to terminal",
                    properties: {
                        topicTemplate,
                        ...topicBody,
                    },
                });

                return h.response().code(201);
            } catch (error: any) {
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { ...error },
                });

                const message = error.message;
                if (message?.errorCode) {
                    const errorMessage = { error: new ResponseErrorModel(message.errorCode, message.errorMessage) };
                    return h.response(errorMessage).code(message.httpStatusCode);
                } else {
                    if (typeof error === "object") {
                        throw new Error(JSON.stringify(error));
                    }
                    throw new Error("internal error");
                }
            }
        },
    };
};

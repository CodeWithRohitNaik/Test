import { PairingStatusEnum } from "@src/models/enums";
import { BAD_REQUEST, FAILED_VERIFY, NOT_FOUND_PAIRING } from "@src/models/response.constants";
import { ErrorDetail, ResponseErrorModel } from "@src/models/response.error.model";
import { RouteConfig } from "@src/models/route.config";
import { PairingService } from "@src/services/v1/pairing.service";
import * as pairingSchema from "@src/validations/pairing.validation.schema";
import * as appInsights from "applicationinsights";

export const createVerify = async (pairingService: PairingService): Promise<RouteConfig> => {
    return {
        description: "Verify pairing creation",
        notes: ["Verify pairing creation"],
        validate: {
            failAction: async (request, h, error: any) => {
                const errorDetails = error.details.map((detail: any) => new ErrorDetail("", "", detail.message));
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { transaction: request.payload },
                });

                const errorMessage = {
                    error: new ResponseErrorModel(BAD_REQUEST.responseCode, BAD_REQUEST.message, "", errorDetails),
                };
                return h.response(errorMessage).code(BAD_REQUEST.httpStatusCode).takeover();
            },
            params: pairingSchema.postVerifyParamSchema,
            payload: pairingSchema.postVerifyPayloadSchema,
            options: {
                allowUnknown: true,
                abortEarly: false,
            },
        },
        tags: ["api"],
        handler: async (request, h) => {
            appInsights.defaultClient.trackEvent({
                name: "Verify pairing request received",
                properties: request.payload as object,
            });
            try {
                const { dispatchId } = request.params as { dispatchId: string };
                const { dispatchDeviceId, terminalSerialId, terminalpairedCode } = request.payload as {
                    dispatchDeviceId: string;
                    terminalSerialId: string;
                    terminalpairedCode: string;
                };

                const result = await pairingService.getByPairingIds(dispatchId, dispatchDeviceId, terminalSerialId);
                if (result.length === 0) {
                    const errorMessage = {
                        error: new ResponseErrorModel(NOT_FOUND_PAIRING.responseCode, NOT_FOUND_PAIRING.message),
                    };
                    return h.response(errorMessage).code(NOT_FOUND_PAIRING.httpStatusCode);
                }
                if (result[0].id !== terminalpairedCode) {
                    const errorMessage = {
                        error: new ResponseErrorModel(FAILED_VERIFY.responseCode, FAILED_VERIFY.message),
                    };
                    return h.response(errorMessage).code(FAILED_VERIFY.httpStatusCode);
                }
                const updatedPairing = { ...result[0], status: PairingStatusEnum.ACTIVE, updatedat: new Date() };
                await pairingService.upsert(updatedPairing);
                return h.response().code(200);
            } catch (error: any) {
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { ...error },
                });

                const message = error.message;
                if (message?.errorCode) {
                    const errorMessage = { error: new ResponseErrorModel(message.errorCode, message.errorMessage) };
                    return h.response(errorMessage).code(message.httpStatusCode);
                } else {
                    throw new Error("internal error");
                }
            }
        },
    };
};

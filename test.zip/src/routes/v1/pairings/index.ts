import { deletePairing } from "./delete.pairing.route";
import { getById } from "./get.pairing.by.id.route";
import { createPairing } from "./post.pairing.route";
import { createVerify } from "./post.verify.route";

export { deletePairing, getById, createVerify, createPairing };

import { create } from "./post.payment.route";
import { getById } from "./get.payment.by.id.route";

export { create, getById };

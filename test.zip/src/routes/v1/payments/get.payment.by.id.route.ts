import * as appInsights from "applicationinsights";
import { RouteConfig } from "@src/models/route.config";
import { PaymentService } from "@src/services/v1/payment.service";
import { ErrorDetail, Payment, ResponseErrorModel } from "@src/models";
import { NOT_FOUND_PAYMENT } from "@src/models/response.constants";
import * as paymentSchema from "@src/validations/payment.validation.schema";
import { removeUnderscoreFields } from "@src/utils/utils";

export const getById = async (paymentService: PaymentService): Promise<RouteConfig> => {
    if (!paymentService) {
        throw new Error("paymentService must be passed in");
    }
    return {
        description: "Get payment by id",
        notes: ["Get payment by id"],
        validate: {
            failAction: async (request, h, error: any) => {
                const errorDetails = error.details.map((detail: any) => new ErrorDetail("", "", detail.message));
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { transaction: request.payload },
                });

                const errorMessage = {
                    error: new ResponseErrorModel(
                        NOT_FOUND_PAYMENT.responseCode,
                        NOT_FOUND_PAYMENT.message,
                        "",
                        errorDetails
                    ),
                };
                return h.response(errorMessage).code(NOT_FOUND_PAYMENT.httpStatusCode).takeover();
            },
            params: paymentSchema.getPaymentSchema,
            options: {
                allowUnknown: true,
                abortEarly: false,
            },
        },
        tags: ["api"],
        handler: async (request, h) => {
            try {
                const { dispatchId, paymentRequestId } = request.params as {
                    dispatchId: string;
                    paymentRequestId: string;
                };
                const result = await paymentService.getByPaymentId(paymentRequestId, dispatchId);
                if (result.length === 0) {
                    const errorMessage = {
                        error: new ResponseErrorModel(NOT_FOUND_PAYMENT.responseCode, NOT_FOUND_PAYMENT.message),
                    };
                    return h.response(errorMessage).code(NOT_FOUND_PAYMENT.httpStatusCode);
                }
                return h.response(removeUnderscoreFields(result[0])).code(200);
            } catch (error: any) {
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { ...error },
                });

                const message = error.message;
                if (message?.errorCode) {
                    const errorMessage = { error: new ResponseErrorModel(message.errorCode, message.errorMessage) };
                    return h.response(errorMessage).code(message.httpStatusCode);
                } else {
                    throw new Error("internal error");
                }
            }
        },
    };
};

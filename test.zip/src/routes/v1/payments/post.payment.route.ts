import { ErrorDetail, Payment, PaymentRequest, ResponseErrorModel, RouteConfig } from "@src/models";
import { PaymentStatusEnum, PairingStatusEnum } from "@src/models/enums";
import { FAILED_PAYMENT } from "@src/models/response.constants";
import { PairingService } from "@src/services/v1/pairing.service";
import { PaymentService } from "@src/services/v1/payment.service";
import { WebhookService } from "@src/services/v1/webhook.service";
import { MqttBrokerService } from "@src/shared/services/mqtt.broker.service";
import * as paymentSchema from "@src/validations/payment.validation.schema";
import * as appInsights from "applicationinsights";

export const create = async (
    paymentService: PaymentService,
    webhookService: WebhookService,
    mqttBrokerService: MqttBrokerService,
    pairingService: PairingService
): Promise<RouteConfig> => {
    if (!paymentService) {
        throw new Error("PaymentService must be passed in");
    }

    return {
        description: "Create a new payment",
        notes: ["Create a new payment"],
        validate: {
            failAction: async (request, h, error: any) => {
                const errorDetails = error.details.map((detail: any) => new ErrorDetail("", "", detail.message));
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { transaction: request.payload },
                });
                const errorMessage = {
                    error: new ResponseErrorModel(FAILED_PAYMENT.responseCode, FAILED_PAYMENT.message, "", errorDetails),
                };
                return h.response(errorMessage).code(FAILED_PAYMENT.httpStatusCode).takeover();
            },
            payload: paymentSchema.postPaymentSchema,
            options: {
                allowUnknown: true,
                abortEarly: false,
            },
        },
        tags: ["api"],
        handler: async (request, h) => {
            appInsights.defaultClient.trackEvent({
                name: "Payment request received",
                properties: request.payload as PaymentRequest,
            });
            try {
                const payload = request.payload as PaymentRequest;

                const dispatchId = request.params.dispatchId;
                if (!dispatchId) {
                    throw new Error("dispatchId is required");
                }

                const dispatchDeviceId = payload.data.dispatch.dispatchDeviceId;
                if (!dispatchDeviceId) {
                    throw new Error("dispatchDeviceId is required");
                }

                const pairingTable = await pairingService.getByParams([
                    { name: "dispatchDeviceId", value: dispatchDeviceId },
                ]);
                const pairingFromDb = pairingTable[0];
                if (!pairingFromDb) {
                    throw new Error("Not found pairing details");
                }

                const paringStatus = pairingFromDb.status;
                if (pairingFromDb.status !== PairingStatusEnum.ACTIVE) {
                    throw new Error("Pairing is not active");
                }

                const paymentModel: Payment = {
                    id: payload.id,
                    dispatchId: dispatchId,
                    dispatchDeviceId: dispatchDeviceId,
                    request: payload,
                    response: {},
                    status: PaymentStatusEnum.REQUESTED,
                    createdAt: new Date(),
                    updatedAt: new Date(),
                };

                await paymentService.saveToBlob(paymentModel);
                await paymentService.upsert(paymentModel);
                const topic = `payment/${pairingFromDb.terminalId}/transaction/request`;
                const tag = payload.type;

                await mqttBrokerService.sendMessageToMQTTTopic(topic, JSON.stringify(paymentModel.request), tag);

                appInsights.defaultClient.trackEvent({
                    name: "Sent payment-request to terminal",
                    properties: {
                        topic,
                        ...paymentModel.request,
                    },
                });

                const response = {
                    paymentRequestId: payload.id,
                };

                const res = response;
                return h.response(res).code(202);
            } catch (error: any) {
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { ...error },
                });
                const message = error.message;
                if (message?.errorCode) {
                    const errorMessage = { error: new ResponseErrorModel(message.errorCode, message.errorMessage) };
                    return h.response(errorMessage).code(message.httpStatusCode);
                } else {
                    throw new Error("internal error");
                }
            }
        },
    };
};

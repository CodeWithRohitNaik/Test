import * as appInsights from "applicationinsights";
import { v4 as uuidv4 } from "uuid";

import { RouteConfig } from "@src/models/route.config";
import { WebhookService } from "@src/services/v1/webhook.service";
import * as notificationSchema from "@src/validations/notification.validation.schema";
import { Webhook, ResponseErrorModel, ErrorDetail, WebhookStatusEnum } from "@src/models";
import { ALREADY_REGISTERED_WEBHOOK, FAILED_WEBHOOK_REGISTER } from "@src/models/response.constants";

export const registerWebhook = async (webhookService: WebhookService): Promise<RouteConfig> => {
    if (!webhookService) {
        throw new Error("WebhookService must be passed in");
    }

    return {
        description: "Register a new webhook",
        notes: ["Register a new webhook"],
        validate: {
            failAction: async (request, h, error: any) => {
                const errorDetails = error.details.map((detail: any) => new ErrorDetail("", "", detail.message));
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { transaction: request.payload },
                });

                const errorMessage = {
                    error: new ResponseErrorModel(
                        FAILED_WEBHOOK_REGISTER.responseCode,
                        FAILED_WEBHOOK_REGISTER.message,
                        "",
                        errorDetails
                    ),
                };
                return h.response(errorMessage).code(400).takeover();
            },
            params: notificationSchema.registerWebhookParamSchema,
            payload: notificationSchema.registerWebhookSchema,
            options: {
                allowUnknown: true,
                abortEarly: false,
            },
        },
        tags: ["api"],
        handler: async (request, h) => {
            const dispatchId = request.params.dispatchId;
            const webhook: Webhook = Object.assign(new Webhook(), request.payload);
            webhook.dispatchId = dispatchId;
            webhook.id = uuidv4(); // Generate a GUID for the webhook

            try {
                // Check duplicate register
                if (webhook.eventTypes) {
                    for (const eventType of webhook.eventTypes) {
                        const existingWebhooks = await webhookService.getWebhooksByEventType(
                            dispatchId,
                            eventType,
                            webhook.url
                        );
                        if (existingWebhooks && existingWebhooks.resources.length > 0) {
                            throw {
                                message: {
                                    errorCode: ALREADY_REGISTERED_WEBHOOK.responseCode,
                                    errorMessage: ALREADY_REGISTERED_WEBHOOK.message,
                                    httpStatusCode: ALREADY_REGISTERED_WEBHOOK.httpStatusCode,
                                },
                            };
                        }
                    }
                }
                webhook.status = WebhookStatusEnum.ACTIVE;
                await webhookService.create(webhook);

                return h.response({ webhookId: webhook.id, status: "success", message: "" }).code(201);
            } catch (error: any) {
                //Capture error details in App Insights
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { ...error },
                });

                const message = error.message;
                if (message?.errorCode) {
                    const errorMessage = { error: new ResponseErrorModel(message.errorCode, message.errorMessage) };
                    return h.response(errorMessage).code(message.httpStatusCode);
                } else {
                    throw new Error("internal error");
                }
            }
        },
    };
};

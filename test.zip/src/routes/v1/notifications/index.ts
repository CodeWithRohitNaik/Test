import { getWebhookById } from "./get.webhook.by.id.route";
import { deleteWebhookById } from "./delete.webhook.by.id.route";
import { registerWebhook } from "./post.register.webhook.route";

export { getWebhookById, deleteWebhookById, registerWebhook };

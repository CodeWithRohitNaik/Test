import * as appInsights from "applicationinsights";

import { RouteConfig } from "@src/models/route.config";
import { WebhookService } from "@src/services/v1/webhook.service";
import * as notificationSchema from "@src/validations/notification.validation.schema";
import { ResponseErrorModel, ErrorDetail } from "@src/models";
import { BAD_REQUEST, NOT_FOUND_WEBHOOK } from "@src/models/response.constants";
import { removeUnderscoreFields } from "@src/utils/utils";

export const getWebhookById = async (webhookService: WebhookService): Promise<RouteConfig> => {
    if (!webhookService) {
        throw new Error("WebhookService must be passed in");
    }

    return {
        description: "Get webhook by id",
        notes: ["Get webhook by id"],
        validate: {
            failAction: async (request, h, error: any) => {
                const errorDetails = error.details.map((detail: any) => new ErrorDetail("", "", detail.message));
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { transaction: request.payload },
                });
                const errorMessage = {
                    error: new ResponseErrorModel(BAD_REQUEST.responseCode, BAD_REQUEST.message, "", errorDetails),
                };

                return h.response(errorMessage).code(BAD_REQUEST.httpStatusCode).takeover();
            },
            params: notificationSchema.getWebhookSchema,
            options: {
                allowUnknown: true,
                abortEarly: false,
            },
        },
        tags: ["api"],
        handler: async (request, h) => {
            const webhookId = request.params.webhookId;

            try {
                const webhooks = await webhookService.getWithOutPartitionKey(webhookId);
                if (webhooks && webhooks.resources.length === 0) {
                    throw {
                        message: {
                            errorCode: NOT_FOUND_WEBHOOK.responseCode,
                            errorMessage: NOT_FOUND_WEBHOOK.message,
                            httpStatusCode: NOT_FOUND_WEBHOOK.httpStatusCode,
                        },
                    };
                }
                const webhook = webhooks.resources[0];
                const webhookViewModel = removeUnderscoreFields(webhook);

                return h.response(webhookViewModel).code(200);
            } catch (error: any) {
                //Capture error details in App Insights
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { ...error },
                });

                const message = error.message;
                if (message?.errorCode) {
                    const errorMessage = { error: new ResponseErrorModel(message.errorCode, message.errorMessage) };
                    return h.response(errorMessage).code(message.httpStatusCode);
                } else {
                    throw new Error("internal error");
                }
            }
        },
    };
};

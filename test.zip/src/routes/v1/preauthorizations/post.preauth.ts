import * as appInsights from "applicationinsights";
import { FAILED_PAYMENT } from "@src/models/response.constants";
import * as preauthSchema from "@src/validations/preauth.validation.schema";
import { ErrorDetail, ResponseErrorModel, RouteConfig } from "@src/models";
import { PreauthRequest } from "@src/models/preauth.request.model";
import { PreauthService } from "@src/services/v1/preauth.service";
import { v4 as uuidv4 } from "uuid";
import { PreAuthorization } from "@src/models/preauth.model";

const failAction = async (request, h, error: any) => {
    const errorDetails = error.details.map((detail: any) => new ErrorDetail("", "", detail.message));
    appInsights.defaultClient.trackException({
        exception: error,
        properties: { transaction: request.payload },
    });
    const errorMessage = {
        error: new ResponseErrorModel(FAILED_PAYMENT.responseCode, FAILED_PAYMENT.message, "", errorDetails),
    };
    return h.response(errorMessage).code(FAILED_PAYMENT.httpStatusCode).takeover();
};

export const preauth = async (preauthService: PreauthService): Promise<RouteConfig> => {
    if (!preauthService) {
        throw new Error("preauthService must be passed in");
    }

    return {
        description: "Accept pre-auth request",
        notes: [
            "This endpoint accepts a prepayment request payload, saves it to Cosmos DB, forwards the request to terminal service API, and returns the response.",
        ],
        validate: {
            failAction,
            payload: preauthSchema.postPreauthSchema,
            options: {
                allowUnknown: true,
                abortEarly: false,
            },
        },
        tags: ["api", "pre-auth"],
        handler: async (request, h) => {
            try {
                const dispatchId = request.params.dispatchId;
                if (!dispatchId) {
                    throw new Error("dispatchId is required");
                }

                const payload = request.payload as PreauthRequest;
                const preauthModel: PreAuthorization = {
                                    id: payload.preauthRequestId,
                                    dispatchId: dispatchId,
                                    request: payload,
                                    status:null,
                                    createdAt: new Date(),
                                    updatedAt: new Date(),
                                };
                appInsights.defaultClient.trackEvent({
                    name: "Preauth request received",
                    properties: request.payload as PreauthRequest,
                });
                await preauthService.create(preauthModel);
                let res = { preauthRequestId: payload.preauthRequestId, bookingId: payload.bookingId };
                return h.response(res).code(202);
            } catch (error: any) {
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { ...error },
                });
                const message = error.message;
                if (message?.errorCode) {
                    const errorMessage = { error: new ResponseErrorModel(message.errorCode, message.errorMessage) };
                    return h.response(errorMessage).code(message.httpStatusCode);
                } else {
                    throw new Error("internal error");
                }
            }
        },
    };
};

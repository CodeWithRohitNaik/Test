import * as appInsights from "applicationinsights";
import { RouteConfig } from "@src/models/route.config";
import { PreauthService } from "@src/services/v1/preauth.service";
import { ErrorDetail, ResponseErrorModel } from "@src/models";
import { NOT_FOUND_PREAUTH } from "@src/models/response.constants";
import * as preauthSchema from "@src/validations/preauth.validation.schema";
import { removeUnderscoreFields } from "@src/utils/utils";

export const getById = async (preauthtService: PreauthService): Promise<RouteConfig> => {
    if (!preauthtService) {
        throw new Error("preauthtService must be passed in");
    }
    return {
        description: "Get pre authorization by id",
        notes: ["Get pre authorization by id"],
        validate: {
            failAction: async (request, h, error: any) => {
                const errorDetails = error.details.map((detail: any) => new ErrorDetail("", "", detail.message));
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { transaction: request.payload },
                });

                const errorMessage = {
                    error: new ResponseErrorModel(
                        NOT_FOUND_PREAUTH.responseCode,
                        NOT_FOUND_PREAUTH.message,
                        "",
                        errorDetails
                    ),
                };
                return h.response(errorMessage).code(NOT_FOUND_PREAUTH.httpStatusCode).takeover();
            },
            params: preauthSchema.getPreauthSchema,
            options: {
                allowUnknown: true,
                abortEarly: false,
            },
        },
        tags: ["api"],
        handler: async (request, h) => {
            try {
                const { dispatchId, preauthRequestId } = request.params as {
                    dispatchId: string;
                    preauthRequestId: string;
                };
                const result = await preauthtService.getByPreauthId(preauthRequestId, dispatchId);
                if (result.length === 0) {
                    const errorMessage = {
                        error: new ResponseErrorModel(NOT_FOUND_PREAUTH.responseCode, NOT_FOUND_PREAUTH.message),
                    };
                    return h.response(errorMessage).code(NOT_FOUND_PREAUTH.httpStatusCode);
                }
                return h.response(removeUnderscoreFields(result[0])).code(200);
            } catch (error: any) {
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { ...error },
                });

                const message = error.message;
                if (message?.errorCode) {
                    const errorMessage = { error: new ResponseErrorModel(message.errorCode, message.errorMessage) };
                    return h.response(errorMessage).code(message.httpStatusCode);
                } else {
                    throw new Error("internal error");
                }
            }
        },
    };
};

import * as appInsights from "applicationinsights";
import { FAILED_PAYMENT } from "@src/models/response.constants";
import * as preauthCompleteSchema from "@src/validations/preauth.complete.validation.schema";
import { ErrorDetail, ResponseErrorModel, RouteConfig } from "@src/models";
import { PreauthService } from "@src/services/v1/preauth.service";
import { v4 as uuidv4 } from "uuid";
import { PreauthCompleteRequest } from "@src/models/preauth.complete.request.model";

const failAction = async (request, h, error: any) => {
    const errorDetails = error.details.map((detail: any) => new ErrorDetail("", "", detail.message));
    appInsights.defaultClient.trackException({
        exception: error,
        properties: { transaction: request.payload },
    });
    const errorMessage = {
        error: new ResponseErrorModel(FAILED_PAYMENT.responseCode, FAILED_PAYMENT.message, "", errorDetails),
    };
    return h.response(errorMessage).code(FAILED_PAYMENT.httpStatusCode).takeover();
};

export const preauthComplete = async (preauthService: PreauthService): Promise<RouteConfig> => {
    if (!preauthService) {
        throw new Error("preauthService must be passed in");
    }

    return {
        description: "Accept pre-auth complete request",
        notes: [
            "This endpoint accepts a prepayment complete request payload, saves it to Cosmos DB, and returns the response.",
        ],
        validate: {
            failAction,
            payload: preauthCompleteSchema.postPreauthCompleteSchema,
            options: {
                allowUnknown: true,
                abortEarly: false,
            },
        },
        tags: ["api", "pre-auth-complete"],
        handler: async (request, h) => {
            try {
                const dispatchId = request.params.dispatchId;
                if (!dispatchId) {
                    throw new Error("dispatchId is required");
                }

                const payload = request.payload as PreauthCompleteRequest;
                payload.dispatchId = dispatchId;
                payload.id = uuidv4();

                appInsights.defaultClient.trackEvent({
                    name: "Preauth request received",
                    properties: request.payload as PreauthCompleteRequest,
                });
                await preauthService.complete(payload);
                let res = { paymentId: payload.id, status: "ok", message: "dummy" }; // this is will be changed as per response next api
                return h.response(res).code(202);
            } catch (error: any) {
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { ...error },
                });
                const message = error.message;
                if (message?.errorCode) {
                    const errorMessage = { error: new ResponseErrorModel(message.errorCode, message.errorMessage) };
                    return h.response(errorMessage).code(message.httpStatusCode);
                } else {
                    throw new Error("internal error");
                }
            }
        },
    };
};

import { ErrorDetail, Event, ResponseCodeEnum, ResponseErrorModel, RouteConfig } from "@src/models";
import { EventService } from "@src/services/v1/event.service";
import * as eventSchema from "@src/validations/event.validation.schema";
import * as appInsights from "applicationinsights";
import { v4 as uuidv4 } from "uuid";

export const create = async (eventService: EventService): Promise<RouteConfig> => {
    if (!eventService) {
        throw new Error("EventService must be passed in");
    }

    return {
        description: "Create a new event",
        notes: ["Create a new event"],
        validate: {
            failAction: async (request, h, error: any) => {
                const errorDetails = error.details.map((detail: any) => new ErrorDetail("", "", detail.message));
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { event: request.payload },
                });
                const errorMessage = {
                    error: new ResponseErrorModel(ResponseCodeEnum.E01, "Failed to process event", "", errorDetails),
                };
                return h.response(errorMessage).code(400).takeover();
            },
            payload: eventSchema.postEventSchema,
            options: {
                allowUnknown: true,
                abortEarly: false,
            },
        },
        tags: ["api"],
        handler: async (request, h) => {
            appInsights.defaultClient.trackEvent({
                name: "Event received",
                properties: request.payload as any,
            });
            try {
                const payload = request.payload as any;
                const dispatchId = request.params.dispatchId;

                if (!dispatchId) {
                    throw new Error("dispatchId is required");
                }

                const eventModel: Event = {
                    id: uuidv4(),
                    eventType: payload.eventType,
                    eventTime: payload.eventTime,
                    dispatchDeviceId: payload.dispatchDeviceId ?? "N/A",
                    details: payload.details,
                    createdAt: new Date(),
                    updatedAt: new Date(),
                };

                await eventService.upsert(eventModel);

                const response = {
                    status: "success",
                    message: "Event received successfully.",
                };

                return h.response(response).code(200);
            } catch (error: any) {
                appInsights.defaultClient.trackException({
                    exception: error,
                    properties: { ...error },
                });
                const message = error.message;
                if (message?.errorCode) {
                    const errorMessage = { error: new ResponseErrorModel(message.errorCode, message.errorMessage) };
                    return h.response(errorMessage).code(message.httpStatusCode);
                } else {
                    throw new Error("internal error");
                }
            }
        },
    };
};

import { EventService } from "@src/services/v1/event.service";
import * as postEventRoute from "./post.event.route";

export const create = async (eventService: EventService) => {
    return await postEventRoute.create(eventService);
};

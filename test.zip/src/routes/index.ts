import { ServerRoute } from "@hapi/hapi";
import { Services } from "@src/models/services";
import * as pairingsV1 from "./v1/pairings";
import * as paymentsV1 from "./v1/payments";
import * as preauthV1 from "./v1/preauthorizations";
import * as notificationsV1 from "./v1/notifications";
import * as eventsV1 from "./v1/events";

const create = async function (services: Services): Promise<ServerRoute[]> {
    const getPairingV1 = await pairingsV1.getById(services.pairingServiceV1);
    const createPairingV1 = await pairingsV1.createPairing(services.pairingServiceV1, services.mqttBrokerService);
    const deletePairingV1 = await pairingsV1.deletePairing(services.pairingServiceV1, services.mqttBrokerService);
    const createVerifyV1 = await pairingsV1.createVerify(services.pairingServiceV1);
    const createPaymentV1 = await paymentsV1.create(
        services.paymentServiceV1,
        services.webhookServiceV1,
        services.mqttBrokerService,
        services.pairingServiceV1
    );
    const getPaymentV1 = await paymentsV1.getById(services.paymentServiceV1);
    const getWebhookV1 = await notificationsV1.getWebhookById(services.webhookServiceV1);
    const deleteWebhookV1 = await notificationsV1.deleteWebhookById(services.webhookServiceV1);
    const registerWebhookV1 = await notificationsV1.registerWebhook(services.webhookServiceV1);
    const createPreauthV1 = await preauthV1.preauth(services.preauthServiceV1);
    const completePreauthV1 = await preauthV1.preauthComplete(services.preauthServiceV1);
    const createEventV1 = await eventsV1.create(services.eventServiceV1);
    const getPreauthV1 = await preauthV1.getById(services.preauthServiceV1);

    return [
        // V1.0
        /**
         * Pairings
         */
        {
            method: "GET",
            path: "/v1.0/pairing/dispatch/{dispatchId}/dispatchDevice/{dispatchDeviceId}/terminal/{terminalSerialId}",
            options: getPairingV1,
        },
        {
            method: "POST",
            path: "/v1.0/pairing/dispatch/{dispatchId}/terminal",
            options: createPairingV1,
        },
        {
            method: "DELETE",
            path: "/v1.0/pairing/dispatch/{dispatchId}/terminal",
            options: deletePairingV1,
        },
        {
            method: "POST",
            path: "/v1.0/pairing/dispatch/{dispatchId}/verify",
            options: createVerifyV1,
        },
        /**
         * Payments
         */
        {
            method: "POST",
            path: "/v1.0/payment/dispatch/{dispatchId}/request",
            options: createPaymentV1,
        },
        {
            method: "GET",
            path: "/v1.0/payment/dispatch/{dispatchId}/request/{paymentRequestId}/payments",
            options: getPaymentV1,
        },
        /**
         * Pre-Authorizations
         */
        {
            method: "POST",
            path: "/v1.0/preauthorization/dispatch/{dispatchId}/request",
            options: createPreauthV1,
        },
        {
            method: "POST",
            path: "/v1.0/preauthorization/dispatch/{dispatchId}/complete",
            options: completePreauthV1,
        },
        {
            method: "GET",
            path: "/v1.0/preauthorization/dispatch/{dispatchId}/{preauthRequestId}",
            options: getPreauthV1,
        },
        /**
         * Webhooks
         */
        {
            method: "GET",
            path: "/v1.0/webhooks/dispatch/{dispatchId}/{webhookId}",
            options: getWebhookV1,
        },
        {
            method: "DELETE",
            path: "/v1.0/webhooks/dispatch/{dispatchId}/{webhookId}",
            options: deleteWebhookV1,
        },
        {
            method: "POST",
            path: "/v1.0/webhooks/dispatch/{dispatchId}/register",
            options: registerWebhookV1,
        },
        /**
         * Events
         */
        {
            method: "POST",
            path: "/v1.0/events/dispatch/{dispatchId}",
            options: createEventV1,
        },
    ];
};

export default create;

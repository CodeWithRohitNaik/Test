import * as appInsights from "applicationinsights";
import { BlobServiceClient, ContainerClient } from "@azure/storage-blob";

export class BlobService {
    private blobServiceClient: BlobServiceClient;
    private containerClient: ContainerClient;

    constructor(connectionString: string) {
        this.blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);
    }

    async init(containerName: string) {
        this.containerClient = this.blobServiceClient.getContainerClient(containerName);
        if (!(await this.containerClient.exists())) {
            await this.containerClient.create();
        }
    }

    async upload(blobName: string, data: string, contentType: string) {
        const blockBlobClient = this.containerClient.getBlockBlobClient(blobName);
        await blockBlobClient.uploadData(Buffer.from(data), {
            blobHTTPHeaders: {
                blobContentType: contentType,
            },
        });
    }
}

import * as appInsights from "applicationinsights";
import { ServiceBusClient, ServiceBusSender, ServiceBusReceiver } from "@azure/service-bus";

export class ServiceBusService {
    private serviceBusClient: ServiceBusClient;
    private sender: ServiceBusSender;
    private receiver: ServiceBusReceiver;
    private deadLetterReceiver: ServiceBusReceiver;

    constructor(endpoint: string) {
        try {
            this.serviceBusClient = new ServiceBusClient(endpoint);
        } catch (err: any) {
            appInsights.defaultClient.trackException({
                exception: err,
                properties: { endpoint },
            });
        }
    }

    async initSender(queueOrTopicName: string) {
        try {
            this.sender = this.serviceBusClient.createSender(queueOrTopicName);
        } catch (err: any) {
            appInsights.defaultClient.trackException({
                exception: err,
                properties: { queueOrTopicName },
            });
        }
    }

    async initReceiverForQueue(queueName: string) {
        try {
            this.receiver = this.serviceBusClient.createReceiver(queueName);
        } catch (err: any) {
            appInsights.defaultClient.trackException({
                exception: err,
                properties: { queueName },
            });
        }
    }

    async initReceiverForSubscription(topicName: string, subscriptionName: string) {
        try {
            this.receiver = this.serviceBusClient.createReceiver(topicName, subscriptionName);
        } catch (err: any) {
            appInsights.defaultClient.trackException({
                exception: err,
                properties: { topicName, subscriptionName },
            });
        }
    }

    async initDeadLetterReceiverForQueue(queueName: string) {
        try {
            this.deadLetterReceiver = this.serviceBusClient.createReceiver(queueName, {
                subQueueType: "deadLetter",
            });
        } catch (err: any) {
            appInsights.defaultClient.trackException({
                exception: err,
                properties: { queueName },
            });
        }
    }

    async initDeadLetterReceiverForSubscription(topicName: string, subscriptionName: string) {
        try {
            this.deadLetterReceiver = this.serviceBusClient.createReceiver(topicName, subscriptionName, {
                subQueueType: "deadLetter",
            });
        } catch (err: any) {
            appInsights.defaultClient.trackException({
                exception: err,
                properties: { topicName, subscriptionName },
            });
        }
    }

    async sendMessage(subject: string, message: any) {
        try {
            if (message) {
                const messages = [
                    {
                        subject: subject,
                        body: message,
                    },
                ];

                await this.sender.sendMessages(messages[0]);
                appInsights.defaultClient.trackEvent({
                    name: "ServiceBusService Send Message",
                    properties: {
                        ...messages[0],
                    },
                });
            } else {
                appInsights.defaultClient.trackEvent({
                    name: "ServiceBusService Send Message Empty or Undefined",
                    properties: { ...message },
                });
            }
        } catch (err: any) {
            throw new Error("ServiceBusService Send Message Error");
        }
    }

    async sendMessages(messages: any) {
        try {
            if (messages && messages.length > 0) {
                let batch = await this.sender.createMessageBatch();
                for (let i = 0; i < messages.length; i++) {
                    const message = messages[i];
                    if (!batch.tryAddMessage(message)) {
                        await this.sender.sendMessages(batch);
                        batch = await this.sender.createMessageBatch();

                        if (!batch.tryAddMessage(messages[i])) {
                            throw new Error("Message too big to fit in a batch");
                        }
                    }
                }

                await this.sender.sendMessages(batch);
            } else {
                appInsights.defaultClient.trackEvent({
                    name: "ServiceBusService Send Messages Empty or Undefined",
                    properties: { ...messages },
                });
            }
        } catch (err: any) {
            throw new Error("ServiceBusService Send Messages Error");
        }
    }

    getReceiver(): ServiceBusReceiver {
        if (!this.receiver) {
            throw new Error("Receiver not initialized. Call initReceiver first.");
        }
        return this.receiver;
    }

    getDeadLetterReceiverForQueue(): ServiceBusReceiver {
        if (!this.deadLetterReceiver) {
            throw new Error("DeadLetterReceiverForQueue not initialized. Call initDeadLetterReceiverForQueue first.");
        }
        return this.deadLetterReceiver;
    }

    getDeadLetterReceiverForSubscription(): ServiceBusReceiver {
        if (!this.deadLetterReceiver) {
            throw new Error(
                "DeadLetterReceiverForSubscription not initialized. Call initDeadLetterReceiverForSubscription first."
            );
        }
        return this.deadLetterReceiver;
    }
}

import * as appInsights from "applicationinsights";
import { CosmosClient, SqlQuerySpec } from "@azure/cosmos";

export class CosmosDbService {
    private dbClient: CosmosClient;
    private databaseId: string;
    private collectionId: string;

    constructor(endpoint: string, key: string) {
        try {
            this.dbClient = new CosmosClient({ endpoint, key });
        } catch (err: any) {
            appInsights.defaultClient.trackException({
                exception: err,
                properties: { ...err },
            });
        }
    }

    async init(databaseId: string, collectionId: string) {
        try {
            const { database } = await this.dbClient.databases.createIfNotExists({
                id: databaseId,
            });
            const { container } = await database.containers.createIfNotExists({
                id: collectionId,
            });
            this.databaseId = databaseId;
            this.collectionId = collectionId;
        } catch (err: any) {
            appInsights.defaultClient.trackException({
                exception: err,
                properties: { ...err },
            });
        }
    }

    async create(item: any): Promise<any> {
        if (!item.id) throw new Error("id property is required");

        const document = Object.assign({}, item, {
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
        });

        await this.dbClient.database(this.databaseId).container(this.collectionId).items.create(document);
    }

    async upsert(item: any): Promise<any> {
        if (!item.id) throw new Error("id property is required");

        const document = Object.assign({}, item, {
            updatedAt: new Date().toISOString(),
        });

        await this.dbClient.database(this.databaseId).container(this.collectionId).items.upsert(document);
    }

    async get(id: string): Promise<any> {
        return await this.dbClient.database(this.databaseId).container(this.collectionId).item(id).read();
    }

    async remove(id: string, partitionKey: string): Promise<any> {
        return await this.dbClient.database(this.databaseId).container(this.collectionId).item(id, partitionKey).delete();
    }

    async getWithPartitionKey(id: string, partitionKey: string): Promise<any> {
        if (!id) throw new Error("id property is required");
        if (!partitionKey) throw new Error("partitionKey is required");

        return await this.dbClient.database(this.databaseId).container(this.collectionId).item(id, partitionKey).read();
    }

    async getByQuery(querySpec: SqlQuerySpec): Promise<any> {
        if (!querySpec) throw new Error("SqlQuerySpec is required");
        return await this.dbClient.database(this.databaseId).container(this.collectionId).items.query(querySpec).fetchAll();
    }
}

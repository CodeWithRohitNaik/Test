import * as appInsights from "applicationinsights";
import { EventHubProducerClient, EventHubConsumerClient, RetryOptions } from "@azure/event-hubs";

export class EventHubService {
    private producerClient: EventHubProducerClient;
    private consumerClient: EventHubConsumerClient;

    constructor(
        consumerGroup: string,
        connectionString: string,
        eventHubName: string,
        maxRetries: string,
        retryDelayMs: string,
        timeoutMs: string
    ) {
        const retryOptions: RetryOptions = {
            maxRetries: parseInt(maxRetries),
            retryDelayInMs: parseInt(retryDelayMs),
            timeoutInMs: parseInt(timeoutMs),
        };

        try {
            this.producerClient = new EventHubProducerClient(connectionString, eventHubName, { retryOptions });
            this.consumerClient = new EventHubConsumerClient(consumerGroup, connectionString, eventHubName);
        } catch (error: any) {
            appInsights.defaultClient.trackException({
                exception: error,
                properties: { connectionString },
            });
        }
    }

    // TODO: Update the type of messages
    async sendMessages(messages: any) {
        try {
            const eventDataBatch = await this.producerClient.createBatch();
            messages.forEach((message) => {
                eventDataBatch.tryAdd({ body: message });
            });

            await this.producerClient.sendBatch(eventDataBatch);
        } catch (err: any) {
            throw err;
        }
    }

    getConsumerClient(): EventHubConsumerClient {
        if (!this.consumerClient) {
            throw new Error("Receiver not initialized.");
        }
        return this.consumerClient;
    }
}

import { AzureCreateClientErrorResponse, AzureCreateClientResponse, AzureTokenResponse } from "@src/models/azure.model";
import * as appInsights from "applicationinsights";
import mqtt, { MqttClient } from "mqtt";
import { v4 as uuidv4 } from "uuid";
import axios from "axios";

export class MqttBrokerService {
    private mqttHost: string;
    private mqttPort: string;
    private mqttProtocol: string;
    private keyPEM: string;
    private certPEM: string;
    private mqttClientMaps: Map<string, MqttClient> = new Map();
    private azureTokenCache: AzureTokenResponse | null = null;
    private mqttCloudClientName: string;

    constructor(
        mqttProtocol: string = "mqtts",
        mqttHost: string,
        mqttPort: string,
        keyPEM: string,
        certPEM: string,
        mqttCloudClientName: string
    ) {
        this.mqttProtocol = mqttProtocol;
        this.mqttHost = mqttHost;
        this.mqttPort = mqttPort;
        this.keyPEM = keyPEM;
        this.certPEM = certPEM;
        this.mqttCloudClientName = mqttCloudClientName;
    }

    async init(): Promise<void> {
        await this.getMqttClientByName(this.mqttCloudClientName);
    }

    async sendMessageToMQTTTopic(topic: string, message: string, tag: string) {
        try {
            if (!topic) {
                throw new Error(`${tag} No send topic found`);
            }
            if (!message) {
                throw new Error(`${tag}  No send message found`);
            }

            const mqttClient: MqttClient = await this.getMqttClientByName(this.mqttCloudClientName);
            await mqttClient.publishAsync(topic, message);
        } catch (error: any) {
            appInsights.defaultClient.trackException({
                exception: error,
                properties: { ...error },
            });
            return false;
        }
        // TODO: Return any value?
        return true;
    }

    private async getMqttClientByName(mqttCloudClientName: string) {
        let mqttClientMap = this.mqttClientMaps.get(mqttCloudClientName);
        if (mqttClientMap) {
            return mqttClientMap;
        } else {
            const sessionId = uuidv4();
            const options = {
                clientId: sessionId,
                clean: true,
                connectTimeout: 4000,
                /**
                 * By default, EMQX allows clients to connect without authentication.
                 * https://docs.emqx.com/en/enterprise/v4.4/advanced/auth.html#anonymous-login
                 */
                /** username is whatever value you set it to in Event Grid clients list settings.
                 * AFAIK Event Grid MQTT broker cares about this field. It can't be random.
                 * I happen to set it the same as the clientId.
                 * Haven't tried not sending it.. maybe it just can't be present and wrong.
                 * We are not using username:password auth, but username still seems to matter.
                 * Leave password empty.
                 */
                username: mqttCloudClientName,
                password: "",
                reconnectPeriod: 1000,
                // Enable the SSL/TLS, whether a client verifies the server's certificate chain and host name
                //rejectUnauthorized: true,
                rejectUnauthorized: false,
                // for more options and details, please refer to https://github.com/mqttjs/MQTT.js#mqttclientstreambuilder-options
                key: Buffer.from(""),
                cert: Buffer.from(""),
            };

            let connectUrl = `${this.mqttProtocol}://${this.mqttHost}:${this.mqttPort}`;
            if (["ws", "wss"].includes(this.mqttProtocol)) {
                // mqtt: MQTT-WebSocket uniformly uses /path as the connection path,
                // which should be specified when connecting, and the path used on EMQX is /mqtt.
                connectUrl += "/mqtt";
            }

            /**
             * If you are using mutual (two-way) TLS authentication, you need to pass the CA, client certificate, and client private key.
             */
            if (["mqtts", "wss"].includes(this.mqttProtocol)) {
                const { keyPEM } = JSON.parse(this.keyPEM || "");
                const { certPEM } = JSON.parse(this.certPEM || "");
                options["key"] = Buffer.from(keyPEM, "utf-8");
                options["cert"] = Buffer.from(certPEM, "utf-8");
            }

            // https://github.com/mqttjs/MQTT.js#qos
            const qos = 0;
            let mqttClient: MqttClient = await mqtt.connectAsync(connectUrl, options);

            // Handle MQTT connection
            // https://github.com/mqttjs/MQTT.js#event-connect
            // mqttClient.on("connect", () => {
            //     console.debug("Connected to MQTT broker");
            // });

            // Receive all messages from the MQTT broker to MQTT.Broker Routing

            this.mqttClientMaps.set(mqttCloudClientName, mqttClient);
            return mqttClient;
        }
    }
}

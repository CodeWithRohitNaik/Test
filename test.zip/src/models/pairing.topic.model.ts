export class PairingRequest {
    id: string;
    type: string;
    localTimeIso: string;
    version: string;
    data: PairingRequestData;
}

export class PairingResponse {
    id: string;
    type: string;
    localTimeIso: string;
    version: string;
    code: number;
    data: PairingResponseData;
}

export class PairingEvents {
    id: string;
    type: string;
    localTimeIso: string;
    version: string;
}

export class PairingRequestData {
    request: string;
    dispatchSystemId: string;
    pairingId: string;
}

export class PairingResponseData {
    response: string;
    pairingId: string;
}

import { Location } from "./preauth.shared";

export class PreauthRequest {
    preauthRequestId: string;
    senderDeviceId: string;
    requestedAmountCents: number;
    currencyCode: string;
    bookingId: string;
    pickUpLocation: Location;
    dropOffLocation: Location;
    localTimeIso: string;
}

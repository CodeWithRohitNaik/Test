import { Dispatch, Driver, Extra, Gps, Levy, Other, Tariff, Toll, Vehicle, Waypoint } from "./preauth.shared";

interface PreauthPayment {
    preauthToken: string;
    preauthRequestId: string;
}
interface Fare {
    isMetered: boolean;
    isBooked: boolean;
    metersTravelled: number;
    startTimeIso: string;
    endTimeIso: string;
    meteredAmountCents: number;
    meterExtrasCents: number;
    richTripDataUrl: string;
    pickUpGps: Gps;
    dropOffGps: Gps;
    waypoints: Waypoint[];
    tariffs: Tariff[];
}
interface ExtendedFare {
    tripNumber: string;
    bookingID: string;
    flagFallCents: number;
    meteredAmountCents: number;
    tolls: Toll[];
    levies: Levy[];
    extras: Extra[];
    other: Other[];
}
export class PreauthCompleteRequest {
    dispatchId: string;
    id: string;
    preauthPayments: PreauthPayment[];
    bookingId: string;
    tripId: string;
    localTimeIso: string;
    fare: Fare;
    extendedFare: ExtendedFare;
    vehicle: Vehicle;
    dispatch: Dispatch;
    driver: Driver;
}

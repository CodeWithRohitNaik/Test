import { PaymentRequest } from "./payment.request.model";
import { PaymentResponse } from "./payment.response.model";

export class Payment {
    id: string;
    dispatchId: string;
    dispatchDeviceId: string;
    request: PaymentRequest;
    response: PaymentResponse | {};
    status: string;
    createdAt: Date;
    updatedAt: Date;
}

import { ResponseCodeEnum } from "@src/models";

export class ResponseErrorModel {
    code: ResponseCodeEnum;
    message: string;
    target?: string;
    details?: ErrorDetail[];
    constructor(code: ResponseCodeEnum, message: string, target?: string, details?: ErrorDetail[]) {
        this.code = code;
        this.message = message;
        this.target = target;
        this.details = details;
    }
}

export class ErrorDetail {
    code: string;
    target: string;
    message: string;
    constructor(code: string, target: string, message: string) {
        this.code = code;
        this.target = target;
        this.message = message;
    }
}

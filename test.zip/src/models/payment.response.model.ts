export class PaymentResponse {
    paymentId: string;
    status: string;
    id: string;
    type: string;
    localTimeIso: string;
    version: string;
    code: number;
    data: PaymentResponseData;
}

interface Terminal {
    POSErrorCode: number;
    POSErrorMsg: string;
    appVersion: string;
    clientId: string;
    deviceModel: string;
    merchantId: string;
    paymentAppVersion: string;
    paymentJurisdictionState: string;
    platform: string;
    region: string;
    serialNumber: string;
    shiftId: string;
    terminalId: string;
    updaterAppVersion: string;
}

interface LocationGps {
    lat: number;
    lon: number;
    shortDescription: string;
    timestampIso: string;
}

interface PaymentResponseSummary {
    approvedAmountCents: number;
    paymentLocalTimeIso: string;
    paymentResult: string;
    requestedAmountCents: number;
    tipAddedCents: number;
    tripId: string;
}

interface PaymentResponseDetailed {
    a2BShiftId: string;
    a2BTransactionId: string;
    acquirerTransactionId: string;
    isPartialPayment: boolean;
    isPrePayment: boolean;
    isStandalone: boolean;
    tipAddedCents: number;
    totalTransactionAmountCents: number;
    transactionErrorMessage: string;
    transactionLocalTimeIso: string;
    transactionResult: string;
    transactionReturnCode: string;
}

interface PaymentResponseData {
    terminal: Terminal;
    locationGps: LocationGps;
    paymentResponseSummary: PaymentResponseSummary;
    paymentResponseDetailed: PaymentResponseDetailed[];
}

export enum ResponseCodeEnum {
    A01 = "A01",
    A02 = "A02",
    P01 = "P01",
    P02 = "P02",
    C01 = "C01",
    C02 = "C02",
    C10 = "C10",
    W01 = "W01",
    W02 = "W02",
    W03 = "W03",
    W04 = "W04",
    W05 = "W05",
    E01 = "E01",
}

export enum PaymentStatusEnum {
    REQUESTED = "Requested",
    SUCCESSFULLY = "Successfully",
    FAILED = "Failed",
}

export enum PairingStatusEnum {
    ACTIVE = "active",
    SUCCESS = "Success",
    INACTIVE = "inActive",
}

export enum WebhookStatusEnum {
    ACTIVE = "active",
    INACTIVE = "inActive",
}

export enum WebhookEventTypeEnum {
    PAYMENT_CREATED = "payment.created",
    PAYMENT_FAILED = "payment.failed",
    PAYMENT_RESPONSE = "payment.response",
}

export enum PaymentTypeEnum {
    PAYMENT_REQUEST = "paymentRequest",
    PAYMENT_RESPONSE = "paymentResponse",
}

export enum PaymentResultEnum {
    SUCCESS = "Success",
    FAILED = "Failed",
}

export enum PairingTypeEnum {
    REQUEST = "pairingrequest",
    RESPONSE = "pairingresponse",
}

import { ResponseCodeEnum } from "@src/models";

export const BAD_REQUEST = {
    responseCode: ResponseCodeEnum.A01,
    message: "BAD REQUEST",
    httpStatusCode: 400,
};

export const NOT_FOUND_DISPATCH = {
    responseCode: ResponseCodeEnum.A02,
    message: "NOT FOUND DISPATCH",
    httpStatusCode: 404,
};

export const FAILED_PAYMENT = {
    responseCode: ResponseCodeEnum.P01,
    message: "FAILED PAYMENT",
    httpStatusCode: 403,
};

export const NOT_FOUND_PAYMENT = {
    responseCode: ResponseCodeEnum.P02,
    message: "NOT FOUND PAYMENT",
    httpStatusCode: 404,
};

export const FAILED_PAIRING = {
    responseCode: ResponseCodeEnum.C01,
    message: "FAILED PAIRING",
    httpStatusCode: 403,
};

export const NOT_FOUND_PAIRING = {
    responseCode: ResponseCodeEnum.C02,
    message: "NOT FOUND PAIRING",
    httpStatusCode: 404,
};

export const FAILED_VERIFY = {
    responseCode: ResponseCodeEnum.C10,
    message: "FAILED VERIFY",
    httpStatusCode: 403,
};

export const FAILED_WEBHOOK_REGISTER = {
    responseCode: ResponseCodeEnum.W01,
    message: "FAILED WEBHOOK REGISTER",
    httpStatusCode: 403,
};

export const NOT_FOUND_WEBHOOK = {
    responseCode: ResponseCodeEnum.W02,
    message: "NOT FOUND WEBHOOK",
    httpStatusCode: 404,
};

export const FAILED_DELETE_WEBHOOK = {
    responseCode: ResponseCodeEnum.W03,
    message: "FAILED DELETE WEBHOOK",
    httpStatusCode: 403,
};

export const ALREADY_REGISTERED_WEBHOOK = {
    responseCode: ResponseCodeEnum.W04,
    message: "ALREADY REGISTERD WEBHOOK",
    httpStatusCode: 403,
};

export const ALREADY_REMOVED_WEBHOOK = {
    responseCode: ResponseCodeEnum.W05,
    message: "ALREADY REMOVED WEBHOOK",
    httpStatusCode: 403,
};

export const NOT_FOUND_PREAUTH = {
    responseCode: ResponseCodeEnum.P02,
    message: "NOT FOUND PRE AUTHORIZATION",
    httpStatusCode: 404,
};

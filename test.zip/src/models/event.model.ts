export interface Event {
    id: string;
    eventType: string;
    eventTime: string;
    dispatchDeviceId: string;
    details: {
        driverId?: string;
        meterId?: string;
    };
    createdAt: Date;
    updatedAt: Date;
}

import { WebhookStatusEnum } from "@src/models/enums";
import { PaymentResponse } from "./payment.response.model";

export class Webhook {
    id: string;
    dispatchId: string;
    url: string;
    eventTypes: string[];
    status: WebhookStatusEnum;
}

export class RequestWebhookBodyPayment {
    paymentId: string;
    status: string;
}

export class RequestWebhookBody {
    dispatchId: string;
    paymentId: string;
    merchantId: string;
    dispatchDeviceId: string;
    eventType: string;
    payments: RequestWebhookBodyPayment[];
}

export class RequestWebhook {
    url: string;
    method: string;
    headers: any;
    body: PaymentResponse;
}

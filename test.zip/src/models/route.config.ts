import { Request, ResponseToolkit } from "@hapi/hapi";
import Joi from "joi";

export interface RouteConfig {
    description: string;
    notes: string[];
    validate: {
        failAction: (request: Request, h: ResponseToolkit, err: Error | undefined) => Promise<any>;
        payload?: Joi.ObjectSchema;
        params?: Joi.ObjectSchema;
        options: {
            allowUnknown: boolean;
            abortEarly: boolean;
        };
    };
    tags: string[];
    handler: (request: Request, h: ResponseToolkit) => Promise<any>;
}

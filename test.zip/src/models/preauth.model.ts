import { PreauthRequest } from "./preauth.request.model";

export class PreAuthorization {
    id: string;
    dispatchId: string;
    request: PreauthRequest;
    status: string|null;
    createdAt: Date;
    updatedAt: Date;
}
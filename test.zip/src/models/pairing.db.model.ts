export class PairingTable {
    id: string;
    dispatchId: string;
    dispatchDeviceId: string;
    terminalSerialId: string;
    terminalId: string;
    terminalpairedCode: string;
    createdAt: Date;
    updatedAt: Date;
    status: string;
    pairingHistory?: any[];
}

export interface Location {
    latitude: string;
    longitude: string;
}

export interface Tariff {
    number: string;
    description: string;
}

export interface Gps {
    latitude: string;
    longitude: string;
    fixLocalTimeIso: string;
}

export interface Waypoint extends Gps {}
export interface Toll {
    description: string;
    amountCents: string;
    automaticallyApplied: boolean;
    amountPreset: boolean;
    entryGantryWaypoint: Location;
    exitGantryWaypoint: Location;
}

export interface Levy {
    description: string;
    amountCents: string;
    automaticallyApplied: boolean;
    amountPreset: boolean;
}
export interface Extra {
    description: string;
    amountCents: string;
    automaticallyApplied: boolean;
    amountPreset: boolean;
}
export interface Other {
    description: string;
    amountCents: string;
    automaticallyApplied: boolean;
    amountPreset: boolean;
}
export interface Vehicle {
    registrationPlate: string;
    watModified: boolean;
    vehicleStatus: string;
    vehicleId: string;
}
export interface Dispatch {
    dispatchManufacturer: string;
    dispatchModel: string;
    dispatchSoftwareVersion: string;
    dispatchDeviceId: string;
}

export interface Driver {
    authorisation: string;
    abn: string;
    dispatchId: string;
    dispatchShiftId: string;
}

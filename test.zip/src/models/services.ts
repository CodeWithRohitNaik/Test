import Joi from "joi";

import { PairingService as PairingServiceV1 } from "@src/services/v1/pairing.service";
import { PaymentService as PaymentServiceV1 } from "@src/services/v1/payment.service";
import { PreauthService as PreauthServiceV1 } from "@src/services/v1/preauth.service";
import { WebhookService as WebhookServiceV1 } from "@src/services/v1/webhook.service";
import { EventService as EventServiceV1 } from "@src/services/v1/event.service";
import { EventHubService } from "@src/shared/services/eventhub.service";
import { MqttBrokerService } from "@src/shared/services/mqtt.broker.service";

export interface Services {
    webhookEventHubService: EventHubService;
    Joi: Joi.Root;
    mqttBrokerService: MqttBrokerService;
    paymentServiceV1: PaymentServiceV1;
    pairingServiceV1: PairingServiceV1;
    webhookServiceV1: WebhookServiceV1;
    preauthServiceV1: PreauthServiceV1;
    eventServiceV1: EventServiceV1;
}

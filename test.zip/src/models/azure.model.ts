export interface AzureTokenResponse {
    token_type: string;
    expires_in: string;
    ext_expires_in: string;
    expires_on: string;
    not_before: string;
    resource: string;
    access_token: string;
}

export interface AzureCreateClientResponse {
    properties: {
        description: null;
        authenticationName: string;
        clientCertificateAuthentication: {
            validationScheme: string;
        };
        state: string;
        provisioningState: string;
    };
    systemData: {
        createdBy: string;
        createdByType: string;
        createdAt: string;
        lastModifiedBy: string;
        lastModifiedByType: string;
        lastModifiedAt: string;
    };
    id: string;
    name: string;
    type: string;
}

export interface AzureCreateClientErrorResponse {
    isRetriable: boolean;
    isUserError: boolean;
    error: {
        code: string;
        message: string;
    };
}

export class PaymentRequest {
    id: string;
    type: string;
    localTimeIso: string;
    version: string;
    data: PaymentData;
}

interface PaymentData {
    tripId: string;
    tripNumber?: string;
    bookingId?: string;
    merchantId: string;
    isPartial?: boolean;
    dispatchHandlesPartial?: boolean;
    vehicle: Vehicle;
    driver: Driver;
    meter: Meter;
    dispatch: Dispatch;
    fare: Fare;
    extendedFare: ExtendedFare;
}

interface Vehicle {
    registrationPlate: string;
    watModified: boolean;
    vehicleStatus: string;
    vehicleId: string;
}

interface Driver {
    tssAuthorisationNumber: string;
    abn: string;
    dispatchDriverId: string;
    dispatchShiftId: string;
}

interface Meter {
    meterManufacturer: string;
    meterStatus: string;
    meterModel: string;
    meterSoftwareVersion: string;
    meterId: string;
    meterType: string;
}

export class Dispatch {
    dispatchManufacturer: string;
    dispatchModel: string;
    dispatchSoftwareVersion: string;
    dispatchDeviceId: string;
    dispatchSystemId: string;
}

interface Fare {
    isMetered: boolean;
    isBooked: boolean;
    isPrepayment: boolean;
    metersTravelled: number;
    startTimeIso: string;
    endTimeIso?: string;
    requestedAmountCents: number;
    flagFallAmountCents?: number;
    meteredAmountCents?: number;
    richTripDataUrl?: string;
    pickUpGps?: GpsLocation;
    dropOffGps?: GpsLocation;
    waypoints?: Waypoint[];
    tariffs?: Tariff[];
}

interface GpsLocation {
    lat: number;
    lon: number;
    shortDescription?: string;
    timestampIso: string;
}

interface Tariff {
    id: string;
    name?: string;
    description?: string;
    flagfallAmountCents?: number;
}

interface ExtendedFare {
    tolls?: Toll[];
    levies?: Charge[];
    extras?: Charge[];
    other?: Charge[];
}

interface Toll {
    name: string;
    amountCents: number;
    automaticallyApplied: boolean;
    amountPreset: boolean;
    entryGantryWaypoint?: Waypoint;
    exitGantryWaypoint?: Waypoint;
}

interface Charge {
    name: string;
    amountCents: number;
    automaticallyApplied: boolean;
    amountPreset: boolean;
}

interface Waypoint {
    lat: number;
    lon: number;
    timestampIso?: string;
}

import { SqlQuerySpec } from "@azure/cosmos";
import { Event } from "@src/models/event.model";
import { CosmosDbService } from "@src/shared/services/cosmosdb.service";

const collectionId: string = "events";

export class EventService {
    private cosmosDbService: CosmosDbService;
    private databaseId: string;

    constructor(cosmosService: CosmosDbService, databaseId: string) {
        this.cosmosDbService = cosmosService;
        this.databaseId = databaseId;
    }

    async init(): Promise<any> {
        await this.cosmosDbService.init(this.databaseId, collectionId);
    }

    async create(event: Event): Promise<any> {
        return await this.cosmosDbService.create(event);
    }

    async upsert(event: Event): Promise<any> {
        return await this.cosmosDbService.upsert(event);
    }

    async getByQuery(querySpec: SqlQuerySpec): Promise<Event[]> {
        return (await this.cosmosDbService.getByQuery(querySpec)).resources;
    }

    async getByEventType(eventType: string, dispatchDeviceId?: string): Promise<Event[]> {
        const query: SqlQuerySpec = {
            query:
                "SELECT * FROM c where c.eventType = @eventType" +
                (dispatchDeviceId ? ` AND c.dispatchDeviceId = @dispatchDeviceId` : ""),
            parameters: [{ name: "@eventType", value: eventType }],
        };

        if (!query.parameters) {
            query.parameters = [];
        }

        if (dispatchDeviceId) {
            query.parameters.push({ name: "@dispatchDeviceId", value: dispatchDeviceId });
        }

        return (await this.cosmosDbService.getByQuery(query)).resources;
    }
}

import { SqlQuerySpec } from "@azure/cosmos";
import { BlobService } from "@src/shared/services/blob.service";
import { CosmosDbService } from "@src/shared/services/cosmosdb.service";
import { EventHubService } from "@src/shared/services/eventhub.service";
import { WebhookService } from "./webhook.service";
import { PreauthCompleteRequest } from "@src/models/preauth.complete.request.model";
import { PreAuthorization } from "@src/models/preauth.model";

const collectionId: string = "pre-authorizations";

export class PreauthService {
    private cosmosDbService: CosmosDbService;
    private blobService: BlobService;
    private databaseId: string;
    private eventHubService: EventHubService;
    webHookService: WebhookService;

    constructor(
        cosmosService: CosmosDbService,
        blobService: BlobService,
        databaseId: string,
        eventHubService: EventHubService,
        webHookService: WebhookService
    ) {
        this.cosmosDbService = cosmosService;
        this.blobService = blobService;
        this.databaseId = databaseId;
        this.eventHubService = eventHubService;
        this.webHookService = webHookService;
    }

    async init(): Promise<any> {
        await this.cosmosDbService.init(this.databaseId, collectionId);
    }

    async create(preauth: PreAuthorization): Promise<any> {
        return await this.cosmosDbService.create(preauth);
    }

    async complete(preauthComplete: PreauthCompleteRequest): Promise<any> {
        return await this.cosmosDbService.create(preauthComplete);
    }

    async getByPreauthId(preauthRequestId: string, dispatchId?: string): Promise<PreAuthorization[]> {
            const query: SqlQuerySpec = {
                query: "SELECT * FROM c where c.id = @id" + (dispatchId ? ` AND c.dispatchId = @dispatchId` : ""),
                parameters: [{ name: "@id", value: preauthRequestId }],
            };
    
            if (!query.parameters) {
                query.parameters = [];
            }
    
            if (dispatchId) {
                query.parameters.push({ name: "@dispatchId", value: dispatchId });
            }
    
            return (await this.cosmosDbService.getByQuery(query)).resources;
        }
}

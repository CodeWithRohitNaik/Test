import { SqlQuerySpec } from "@azure/cosmos";
import { earliestEventPosition } from "@azure/event-hubs";

import { Payment } from "@src/models/payment.model";
import { BlobService } from "@src/shared/services/blob.service";
import { CosmosDbService } from "@src/shared/services/cosmosdb.service";
import { EventHubService } from "@src/shared/services/eventhub.service";
import { responseHandler } from "./handlers/payment.handler";
import { WebhookService } from "./webhook.service";

const collectionId: string = "payments";
export class PaymentService {
    private cosmosDbService: CosmosDbService;
    private blobService: BlobService;
    private databaseId: string;
    private eventHubService: EventHubService;
    webHookService: WebhookService;

    constructor(
        cosmosService: CosmosDbService,
        blobService: BlobService,
        databaseId: string,
        eventHubService: EventHubService,
        webHookService: WebhookService
    ) {
        this.cosmosDbService = cosmosService;
        this.blobService = blobService;
        this.databaseId = databaseId;
        this.eventHubService = eventHubService;
        this.webHookService = webHookService;
    }

    async init(): Promise<any> {
        await this.cosmosDbService.init(this.databaseId, collectionId);
        await this.processPaymentEventHub();
    }

    async get(id: string): Promise<any> {
        return await this.cosmosDbService.get(id);
    }

    async create(payment: Payment): Promise<any> {
        return await this.cosmosDbService.create(payment);
    }

    async upsert(payment: Payment): Promise<any> {
        return await this.cosmosDbService.upsert(payment);
    }

    async getByQuery(querySpec: SqlQuerySpec): Promise<Payment> {
        return (await this.cosmosDbService.getByQuery(querySpec)).resources;
    }

    async getByPaymentId(paymentRequestId: string, dispatchId?: string): Promise<Payment[]> {
        const query: SqlQuerySpec = {
            query: "SELECT * FROM c where c.id = @id" + (dispatchId ? ` AND c.dispatchId = @dispatchId` : ""),
            parameters: [{ name: "@id", value: paymentRequestId }],
        };

        if (!query.parameters) {
            query.parameters = [];
        }

        if (dispatchId) {
            query.parameters.push({ name: "@dispatchId", value: dispatchId });
        }

        return (await this.cosmosDbService.getByQuery(query)).resources;
    }

    async saveToBlob(paymentModel: any) {
        const blobName = `payments/${paymentModel.id}.json`;
        const paymentData = JSON.stringify(paymentModel);
        await this.blobService.upload(blobName, paymentData, "application/json");
    }

    private async processPaymentEventHub(): Promise<void> {
        const consumerClient = this.eventHubService.getConsumerClient();
        const subscriptionOptions = {
            startPosition: earliestEventPosition,
        };
        const regex = /^payment\/([^\/]+)\/transaction\/(request|response)$/;

        consumerClient.subscribe(
            {
                processEvents: async (events, context) => {
                    for (const event of events) {
                        const subject = event?.body?.subject;
                        if (!subject || !subject.startsWith("payment")) {
                            await context.updateCheckpoint(event);
                        }

                        if (subject.match(regex)) {
                            if (subject.includes("response")) {
                                await responseHandler(event, this);
                            }
                        }

                        //**
                        //  Add more event handlers here
                        //  */

                        await context.updateCheckpoint(event);
                    }
                },
                processError: async (error, context) => {
                    // error reporting/handling code here
                },
            },
            subscriptionOptions
        );
    }
}

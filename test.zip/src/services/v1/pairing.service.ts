import { SqlQuerySpec } from "@azure/cosmos";
import { v4 as uuidv4 } from "uuid";
import { earliestEventPosition } from "@azure/event-hubs";

import { PairingTable } from "@src/models/pairing.db.model";
import { PairingRequest, PairingRequestData } from "@src/models";
import { CosmosDbService } from "@src/shared/services/cosmosdb.service";
import { EventHubService } from "@src/shared/services/eventhub.service";
import { responseHandler } from "./handlers/pairing.response.handler";
import { eventHandler } from "./handlers/pairing.event.handler";
import { getLocalDateTimeIsoWithFormat } from "@src/utils/utils";

const collectionId: string = "pairings";
export class PairingService {
    private cosmosDbService: CosmosDbService;
    private databaseId: string;
    private eventHubService: EventHubService;

    constructor(cosmosService: CosmosDbService, databaseId: string, eventHubService: EventHubService) {
        this.cosmosDbService = cosmosService;
        this.databaseId = databaseId;
        this.eventHubService = eventHubService;
    }

    async init(): Promise<void> {
        await this.cosmosDbService.init(this.databaseId, collectionId);
        await this.processPairingEventHub();
    }

    async get(id: string): Promise<PairingTable> {
        return (await this.cosmosDbService.get(id)).resources;
    }

    async create(pairing: PairingTable): Promise<void> {
        await this.cosmosDbService.create(pairing);
    }

    async upsert(pairing: PairingTable): Promise<void> {
        await this.cosmosDbService.upsert(pairing);
    }

    async getByQuery(querySpec: SqlQuerySpec): Promise<PairingTable> {
        return (await this.cosmosDbService.getByQuery(querySpec)).resources;
    }

    async getByPairingIds(dispatchId: string, dispatchDeviceId: string, terminalSerialId: string): Promise<PairingTable[]> {
        const query: SqlQuerySpec = {
            query: "SELECT * FROM c where c.dispatchId = @dispatchId and c.dispatchDeviceId = @dispatchDeviceId and c.terminalSerialId = @terminalSerialId",
            parameters: [
                { name: "@dispatchId", value: dispatchId },
                { name: "@dispatchDeviceId", value: dispatchDeviceId },
                { name: "@terminalSerialId", value: terminalSerialId },
            ],
        };
        return (await this.cosmosDbService.getByQuery(query)).resources;
    }

    async getById(id: string): Promise<PairingTable[]> {
        const query: SqlQuerySpec = {
            query: "SELECT * FROM c where c.id = @id",
            parameters: [{ name: "@id", value: id }],
        };
        return (await this.cosmosDbService.getByQuery(query)).resources;
    }

    async getByParams(params: { name: string; value: string }[]): Promise<PairingTable[]> {
        let query = "SELECT * FROM c WHERE c.status = 'active'";
        const parameters = params.map((param) => {
            query += ` AND c.${param.name} = @${param.name}`;
            return { name: `@${param.name}`, value: param.value || null };
        });

        const querySpec: SqlQuerySpec = {
            query,
            parameters,
        };

        return (await this.cosmosDbService.getByQuery(querySpec)).resources;
    }

    async delete(id: string, partitionKey: string): Promise<void> {
        return await this.cosmosDbService.remove(id, partitionKey);
    }

    getPairingTopicBody(pairing: PairingTable, mqttMessageVersion: string, isParingRequest: boolean = true) {
        const topicTemplate = `payment/${pairing.terminalId}/pairing/request`;

        const data: PairingRequestData = {
            request: isParingRequest ? "Pair" : "Unpair",
            pairingId: pairing.id,
            dispatchSystemId: pairing.dispatchDeviceId,
        };

        const topicBody: PairingRequest = {
            id: uuidv4(),
            type: "PairingRequest",
            localTimeIso: getLocalDateTimeIsoWithFormat(),
            version: mqttMessageVersion,
            data: data,
        };

        return { topicTemplate: topicTemplate, topicBody: topicBody };
    }

    private async processPairingEventHub(): Promise<void> {
        const consumerClient = this.eventHubService.getConsumerClient();
        const subscriptionOptions = {
            startPosition: earliestEventPosition,
        };
        const regex = /^payment\/([^\/]+)\/pairing\/(response|events)$/;

        consumerClient.subscribe(
            {
                processEvents: async (events, context) => {
                    for (const event of events) {
                        const subject = event?.body?.subject;
                        if (!subject.startsWith("payment")) {
                            await context.updateCheckpoint(event);
                        }

                        if (subject.match(regex)) {
                            if (subject.includes("response")) {
                                await responseHandler(event, this);
                            }
                        }

                        if (subject.match(regex)) {
                            if (subject.includes("events")) {
                                await eventHandler(event, this);
                            }
                        }

                        //**
                        //  Add more event handlers here
                        //  */

                        await context.updateCheckpoint(event);
                    }
                },
                processError: async (error, context) => {
                    // error reporting/handling code here
                },
            },
            subscriptionOptions
        );
    }
}

import * as appInsights from "applicationinsights";
import { earliestEventPosition } from "@azure/event-hubs";
import axios from "axios";

import { Webhook, RequestWebhook } from "@src/models";
import { CosmosDbService } from "@src/shared/services/cosmosdb.service";
import { EventHubService } from "@src/shared/services/eventhub.service";
import { SqlQuerySpec } from "@azure/cosmos";

const collectionId: string = "webhooks";
export class WebhookService {
    private eventHubService: EventHubService;
    private cosmosDbService: CosmosDbService;
    private databaseId: string;

    constructor(cosmosService: CosmosDbService, databaseId: string, eventHubService: EventHubService) {
        this.cosmosDbService = cosmosService;
        this.databaseId = databaseId;
        this.eventHubService = eventHubService;
    }

    async init(): Promise<any> {
        await this.cosmosDbService.init(this.databaseId, collectionId);
        await this.processWebhook();
    }

    async get(id: string): Promise<any> {
        return await this.cosmosDbService.get(id);
    }

    async update(webhook: Webhook): Promise<Webhook> {
        return await this.cosmosDbService.upsert(webhook);
    }

    async create(webhook: Webhook): Promise<any> {
        return await this.cosmosDbService.create(webhook);
    }

    async delete(productId: string, partitionKey: string): Promise<any> {
        return await this.cosmosDbService.remove(productId, partitionKey);
    }

    async getWithPartitionKey(id: string, partitionKey: string): Promise<Webhook> {
        return await this.cosmosDbService.getWithPartitionKey(id, partitionKey);
    }

    async getWithOutPartitionKey(id: string): Promise<any> {
        const querySpec = {
            query: `SELECT * FROM c WHERE c.id = @id`,
            parameters: [{ name: "@id", value: id }],
        };
        return await this.cosmosDbService.getByQuery(querySpec);
    }

    async getWebhooksByEventType(dispatchId: string, eventType: string, url?: string): Promise<any> {
        const querySpec: SqlQuerySpec = {
            query:
                `SELECT * FROM c WHERE c.dispatchId = @dispatchId AND ARRAY_CONTAINS_ANY(c.eventTypes, @eventType) AND c.status = 'active'` +
                (url ? ` AND c.url = @url` : ""),
            parameters: [
                { name: "@dispatchId", value: dispatchId },
                { name: "@eventType", value: eventType },
            ],
        };

        if (!querySpec.parameters) {
            querySpec.parameters = [];
        }

        if (url) {
            querySpec.parameters.push({ name: "@url", value: url });
        }

        return await this.cosmosDbService.getByQuery(querySpec);
    }

    async requestWebhook(requestWebhook: RequestWebhook): Promise<void> {
        const messages = [requestWebhook];
        await this.eventHubService.sendMessages(messages);
    }

    async requestWebhooks(requestWebhooks: RequestWebhook[]): Promise<void> {
        await this.eventHubService.sendMessages(requestWebhooks);
    }

    async processWebhook(): Promise<void> {
        const consumerClient = this.eventHubService.getConsumerClient();
        const subscriptionOptions = {
            startPosition: earliestEventPosition,
        };
        consumerClient.subscribe(
            {
                processEvents: async (events, context) => {
                    // event processing code goes here
                    for (const event of events) {
                        const webhook = event.body as RequestWebhook;
                        const httpMethod = webhook.method?.toLowerCase() || "post";

                        try {
                            if (httpMethod === "post") {
                                await axios.post(webhook.url, webhook.body, {
                                    headers: webhook.headers,
                                });
                            } else if (httpMethod === "put") {
                                await axios.put(webhook.url, webhook.body, {
                                    headers: webhook.headers,
                                });
                            } else if (httpMethod === "patch") {
                                await axios.patch(webhook.url, webhook.body, {
                                    headers: webhook.headers,
                                });
                            } else if (httpMethod === "delete") {
                                await axios.delete(webhook.url, {
                                    headers: webhook.headers,
                                });
                            }

                            appInsights.defaultClient.trackEvent({
                                name: "Called webhook successfully",
                                properties: { ...webhook },
                            });
                        } catch (error: any) {
                            appInsights.defaultClient.trackException({
                                exception: error,
                                properties: { ...webhook },
                            });

                            throw error;
                        }
                    }
                },
                processError: async (error, context) => {
                    // error reporting/handling code here
                },
            },
            subscriptionOptions
        );
    }
}

import * as appInsights from "applicationinsights";
import { ReceivedEventData } from "@azure/event-hubs";

import { PaymentResponse, RequestWebhook } from "@src/models";
import { PairingService } from "../pairing.service";
import { PaymentResultEnum, PaymentStatusEnum, PaymentTypeEnum, WebhookEventTypeEnum } from "@src/models/enums";

export const eventHandler = async (event: ReceivedEventData, pairingService: PairingService) => {
    if (!event.body.data_base64) {
        return;
    }

    // TODO: Add logic to handle pairing events
};

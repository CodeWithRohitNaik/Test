import * as appInsights from "applicationinsights";
import { ReceivedEventData } from "@azure/event-hubs";

import { PairingResponseData, PairingResponse } from "@src/models";
import { PairingService } from "../pairing.service";
import { PaymentResultEnum, PairingStatusEnum, PairingTypeEnum } from "@src/models/enums";

export const responseHandler = async (event: ReceivedEventData, pairingService: PairingService) => {
    if (!event.body.data_base64) {
        return;
    }

    const responseData = Buffer.from(event.body.data_base64, "base64").toString("utf-8");
    const pairingResponse = JSON.parse(responseData) as PairingResponse;

    if (!pairingResponse.id || !pairingResponse.type || pairingResponse.type.toLowerCase() !== PairingTypeEnum.RESPONSE) {
        return;
    }

    const pairingId = pairingResponse.data.pairingId;
    if (!pairingId) {
        return;
    }

    const pairingFromDb = await pairingService.getById(pairingId);

    // if payment not found in db, log in AppInsights
    if (pairingFromDb?.length === 0) {
        appInsights.defaultClient.trackException({
            exception: new Error("Pairing not found: " + pairingId),
            properties: { pairingResponse: pairingResponse },
        });
        return;
    }

    const updatedParing = pairingFromDb[0];
    if (!updatedParing.pairingHistory) {
        updatedParing.pairingHistory = [];
    }

    updatedParing.pairingHistory.push({
        ...pairingResponse,
    });

    if (pairingResponse.data.response === PaymentResultEnum.SUCCESS) {
        updatedParing.status = PairingStatusEnum.SUCCESS;
        updatedParing.updatedAt = new Date();
    }

    await pairingService.upsert(updatedParing);
};

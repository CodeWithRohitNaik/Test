import { ReceivedEventData } from "@azure/event-hubs";
import { PaymentResponse, RequestWebhook } from "@src/models";
import { PaymentService } from "../payment.service";
import * as appInsights from "applicationinsights";
import { PaymentResultEnum, PaymentStatusEnum, PaymentTypeEnum, WebhookEventTypeEnum } from "@src/models/enums";

export const responseHandler = async (event: ReceivedEventData, paymentService: PaymentService) => {
    if (!event.body.data_base64) {
        return;
    }

    const paymentData = Buffer.from(event.body.data_base64, "base64").toString("utf-8");
    const payment = JSON.parse(paymentData) as PaymentResponse;

    if (!payment.id || payment.type !== PaymentTypeEnum.PAYMENT_RESPONSE) {
        return;
    }
    const paymentFromDb = await paymentService.getByPaymentId(payment.id);

    // if payment not found in db, log in AppInsights
    if (paymentFromDb?.length === 0) {
        appInsights.defaultClient.trackException({
            exception: new Error("Payment not found: " + payment.id),
            properties: { payment: payment },
        });
        return;
    }

    const updatedPayment = paymentFromDb[0];
    updatedPayment.response = payment;

    if (payment.data.paymentResponseSummary.paymentResult === PaymentResultEnum.SUCCESS) {
        updatedPayment.status = PaymentStatusEnum.SUCCESSFULLY;
    } else {
        updatedPayment.status = PaymentStatusEnum.FAILED;
    }

    await paymentService.upsert(updatedPayment);

    // save to blob
    await paymentService.saveToBlob(updatedPayment);

    const webhooks = await paymentService.webHookService.getWebhooksByEventType(
        updatedPayment.dispatchId,
        WebhookEventTypeEnum.PAYMENT_RESPONSE
    );

    if (webhooks.resources.length === 0) {
        return;
    }

    for (const webhook of webhooks.resources) {
        // Start test for sending messages to Event Hub
        const requestWebhook: RequestWebhook = {
            url: webhook.url,
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: payment,
        };

        await paymentService.webHookService.requestWebhook(requestWebhook);
        // End test for sending messages to Event Hub
    }
};

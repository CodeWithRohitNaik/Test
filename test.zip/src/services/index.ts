import Joi from "joi";
import { CosmosDbService } from "@src/shared/services/cosmosdb.service";
import { BlobService } from "@src/shared/services/blob.service";
import { MqttBrokerService } from "@src/shared/services/mqtt.broker.service";
import { EventHubService } from "@src/shared/services/eventhub.service";
import { PaymentService as PaymentServiceV1 } from "@src/services/v1/payment.service";
import { PairingService as PairingServiceV1 } from "@src/services/v1/pairing.service";
import { WebhookService as WebhookServiceV1 } from "@src/services/v1/webhook.service";
import { PreauthService as PreauthServiceV1 } from "@src/services/v1/preauth.service";
import { EventService as EventServiceV1 } from "@src/services/v1/event.service";

const init = async () => {
    const mqttBrokerService = new MqttBrokerService(
        process.env.MQTT_PROTOCOL as string,
        process.env.MQTT_HOST_URL as string,
        process.env.MQTT_PORT as string,
        process.env.MQTT_KEY as string,
        process.env.MQTT_CERT as string,
        (process.env.MQTT_CLOUD_CLIENT as string) || "a2bpaycloudapp"
    );
    await mqttBrokerService.init();

    const webhookEventHubService = new EventHubService(
        process.env.EVENTHUB_WEBHOOK_CONSUMER_GROUP as string,
        process.env.EVENTHUB_CONNECTION_STRING as string,
        process.env.EVENTHUB_WEBHOOK_NAME as string,
        (process.env.WEBHOOK_MAXRETRIES as string) || "5",
        (process.env.WEBHOOK_RETRYDELAY_MS as string) || "60000",
        (process.env.WEHOOK_TIMEOUT_MS as string) || "60000"
    );

    const paymentEventHubService = new EventHubService(
        process.env.EVENTHUB_PAYMENTS_CONSUMER_GROUP_TRANSACTIONS as string,
        process.env.EVENTHUB_CONNECTION_STRING as string,
        process.env.EVENTHUB_PAYMENT_NAME as string,
        (process.env.WEBHOOK_MAXRETRIES as string) || "5",
        (process.env.WEBHOOK_RETRYDELAY_MS as string) || "60000",
        (process.env.WEHOOK_TIMEOUT_MS as string) || "60000"
    );

    const pairingEventHubService = new EventHubService(
        process.env.EVENTHUB_PAYMENTS_CONSUMER_GROUP_PAIRINGS as string,
        process.env.EVENTHUB_CONNECTION_STRING as string,
        process.env.EVENTHUB_PAYMENT_NAME as string,
        (process.env.WEBHOOK_MAXRETRIES as string) || "5",
        (process.env.WEBHOOK_RETRYDELAY_MS as string) || "60000",
        (process.env.WEHOOK_TIMEOUT_MS as string) || "60000"
    );

    const paymentBlobService = new BlobService(process.env.AZURE_STORAGE_CONNECTION_STRING as string);
    await paymentBlobService.init("payments");

    // V1.0

    const pairingServiceV1 = new PairingServiceV1(
        new CosmosDbService(process.env.DOCUMENT_DB_ENDPOINT as string, process.env.DOCUMENT_DB_KEY as string),
        process.env.DOCUMENT_DATABASE_ID as string,
        pairingEventHubService
    );
    await pairingServiceV1.init();

    const webhookServiceV1 = new WebhookServiceV1(
        new CosmosDbService(process.env.DOCUMENT_DB_ENDPOINT as string, process.env.DOCUMENT_DB_KEY as string),
        process.env.DOCUMENT_DATABASE_ID as string,
        webhookEventHubService
    );
    await webhookServiceV1.init();

    const paymentServiceV1 = new PaymentServiceV1(
        new CosmosDbService(process.env.DOCUMENT_DB_ENDPOINT as string, process.env.DOCUMENT_DB_KEY as string),
        paymentBlobService,
        process.env.DOCUMENT_DATABASE_ID as string,
        paymentEventHubService,
        webhookServiceV1
    );
    await paymentServiceV1.init();

    const eventServiceV1 = new EventServiceV1(
        new CosmosDbService(process.env.DOCUMENT_DB_ENDPOINT as string, process.env.DOCUMENT_DB_KEY as string),
        process.env.DOCUMENT_DATABASE_ID as string
    );
    await eventServiceV1.init();

    const preauthServiceV1 = new PreauthServiceV1(
        new CosmosDbService(process.env.DOCUMENT_DB_ENDPOINT as string, process.env.DOCUMENT_DB_KEY as string),
        paymentBlobService,
        process.env.DOCUMENT_DATABASE_ID as string,
        paymentEventHubService,
        webhookServiceV1
    );
    await preauthServiceV1.init();

    return {
        Joi,
        mqttBrokerService,
        webhookEventHubService,
        paymentServiceV1,
        pairingServiceV1,
        webhookServiceV1,
        preauthServiceV1,
        eventServiceV1,
    };
};

export default init;
